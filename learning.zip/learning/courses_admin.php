<?php
date_default_timezone_set("Africa/Lagos");
//include_once('../../secure.php');
include('database_connection.php');
include_once('header_php.php');
?>
<!doctype html>
<html lang="en">

<head>

    <!--====== Required meta tags ======-->
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!--====== Title ======-->
    <title>Swift Online Learning</title>

    <!--====== Favicon Icon ======-->
    <link rel="shortcut icon" href="assets/images/favicon.png" type="image/png">

    <!--====== Bootstrap css ======-->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">

    <!--====== Animate css ======-->
    <link rel="stylesheet" href="assets/css/animate.css">

    <!--====== Fontawesome css ======-->
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">

    <!--====== Magnific Popup css ======-->
    <link rel="stylesheet" href="assets/css/magnific-popup.css">

    <!--====== Nice Select css ======-->
    <link rel="stylesheet" href="assets/css/nice-select.css">

    <!--====== Slick css ======-->
    <link rel="stylesheet" href="assets/css/slick.css">

    <!--====== Default css ======-->
    <link rel="stylesheet" href="assets/css/default.css">

    <!--====== Style css ======-->
    <link rel="stylesheet" href="assets/css/style.css">

    <!--====== Responsive css ======-->
    <link rel="stylesheet" href="assets/css/responsive.css">


</head>

<body>

    <!--====== PRELOADER PART START ======-->

    <div id="preloader">
        <div class="preloader">
            <span></span>
            <span></span>
        </div>
    </div>

    <!--====== PRELOADER PART ENDS ======-->

    <!--====== Header PART START ======-->

    
    <?php include_once 'header.php'; ?>

    <!--====== Header PART ENDS ======-->

    <!--====== Page Banner PART START ======-->

    <section class="page_banner bg_cover" style="background-image: url(assets/images/about_bg.jpg)">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="banner_content text-center">
                        <h4 class="title">Admin</h4>
                        <ul class="breadcrumb justify-content-center">
                            <li><a href="#">Home</a></li>
                            <li><a class="active" href="#">Courses</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!--====== Page Banner PART ENDS ======-->
    
    <!--====== Courses PART START ======-->

    <section class="courses_area pt-100 pb-130">
        <div class="container">
            <div class="row">
                <?php 


                                            // Prepare the paged query
                                            $stmt = $connect->prepare("
                                                SELECT
                                                    *
                                                FROM
                                                    courses ORDER BY date_course_created ASC

                                                LIMIT 10
                                            ");

                                            // Bind the query params
                                           
                                            $stmt->execute();

                                            // Do we have any results?
                                            if ($stmt->rowCount() > 0) {
                                                // Define how we want to fetch the results
                                                $stmt->setFetchMode(PDO::FETCH_ASSOC);
                                                $iterator = new IteratorIterator($stmt);

                                                // Display the results
                                                foreach ($iterator as $row) {
                                                    $id = $row['id'];
                                                    $course_tutor = $row['course_tutor'];
                                                    $course_title = $row['course_title'];
                                                    $course_price = $row['course_price'];
                                                    $course_category = $row['course_category'];
                                                                    
                                                        echo '<div class="col-lg-3 col-sm-6">
                                                        <div class="single_courses courses_gray mt-30">
                                                            <div class="courses_image">
                                                                <a href="course_detail.php?id='.$id.'"><img src="assets/images/courses-1.jpg" alt="courses"></a>
                                                            </div>
                                                            <div class="courses_content">
                                                                <ul class="tag">
                                                                    <li><a href="course_detail.php?id='.$id.'">'.$course_category.'</a></li>
                                                                    
                                                                </ul>
                                                                <div class="courses_author d-flex">
                                                                    <div class="author_image">
                                                                        <img src="assets/images/author-1.jpg" alt="author">
                                                                    </div>
                                                                    <div class="author_name media-body">
                                                                        <a href="course_detail.php?id='.$id.'">'.$course_tutor.'</a>
                                                                    </div>
                                                                </div>
                                                                <h4 class="title"><a href="course_detail.php?id='.$id.'">'.$course_title.' </a></h4>
                                                                <div class="meta d-flex justify-content-between">
                                                                    <ul>
                                                                        <li><a href="#"><i class="fa fa-user-o"></i> 100</a></li>
                                                                        <li><a href="#"><i class="fa fa-star-o"></i> 4.5</a></li>
                                                                    </ul>
                                                                    <span>'.'&#x20A6;'.number_format($course_price,2).'</span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>';
                                                }//endof foreach
                                            }//endof if ($stmt->rowCount() > 0)
                                            else
                                            {
                                                echo '<tr>
                                                        <td>There is no course yet <br><br></td>
                                                        </tr>';
                                            }
                                        ?>
               
                
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <ul class="pagination justify-content-center">
                        <li><a href="#"><i class="fa fa-angle-left"></i></a></li>
                        <li><a class="active" href="#">1</a></li>
                        <li><a href="#">2</a></li>
                        <li><a href="#">3</a></li>
                        <li><a href="#"><i class="fa fa-angle-right"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </section>

    <!--====== Courses PART ENDS ======-->

    <!--====== Footer PART START ======-->

    <?php include_once 'footer.php'; ?>

    <!--====== Footer PART ENDS ======-->
    
    <!--====== BACK TOP TOP PART START ======-->

    <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>

    <!--====== BACK TOP TOP PART ENDS ======-->

    









    <!--====== jquery js ======-->
    <script src="assets/js/vendor/modernizr-3.6.0.min.js"></script>
    <script src="assets/js/vendor/jquery-1.12.4.min.js"></script>

    <!--====== Bootstrap js ======-->
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/popper.min.js"></script>

    <!--====== Slick js ======-->
    <script src="assets/js/slick.min.js"></script>

    <!--====== Magnific Popup js ======-->
    <script src="assets/js/jquery.magnific-popup.min.js"></script>

    <!--====== Counter Up js ======-->
    <script src="assets/js/waypoints.min.js"></script>
    <script src="assets/js/jquery.counterup.min.js"></script>

    <!--====== Nice Select js ======-->
    <script src="assets/js/jquery.nice-select.min.js"></script>
    
    <!--====== Count Down js ======-->
    <script src="assets/js/jquery.countdown.min.js"></script>
    
    <!--====== Appear js ======-->
    <script src="assets/js/jquery.appear.min.js"></script>

    <!--====== Main js ======-->
    <script src="assets/js/main.js"></script>

</body>


<!-- Mirrored from raistheme.com/html/edustdy/edustdy/courses.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 19 Jun 2020 17:18:57 GMT -->
</html>
