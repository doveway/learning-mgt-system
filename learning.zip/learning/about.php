<!doctype html>
<html lang="en">

<head>

    <!--====== Required meta tags ======-->
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!--====== Title ======-->
    <title>Swift Online Learning</title>

    <!--====== Favicon Icon ======-->
    <link rel="shortcut icon" href="assets/images/favicon.png" type="image/png">

    <!--====== Bootstrap css ======-->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">

    <!--====== Animate css ======-->
    <link rel="stylesheet" href="assets/css/animate.css">

    <!--====== Fontawesome css ======-->
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">

    <!--====== Magnific Popup css ======-->
    <link rel="stylesheet" href="assets/css/magnific-popup.css">

    <!--====== Nice Select css ======-->
    <link rel="stylesheet" href="assets/css/nice-select.css">

    <!--====== Slick css ======-->
    <link rel="stylesheet" href="assets/css/slick.css">

    <!--====== Default css ======-->
    <link rel="stylesheet" href="assets/css/default.css">

    <!--====== Style css ======-->
    <link rel="stylesheet" href="assets/css/style.css">

    <!--====== Responsive css ======-->
    <link rel="stylesheet" href="assets/css/responsive.css">


</head>

<body>

    <!--====== PRELOADER PART START ======-->

    <div id="preloader">
        <div class="preloader">
            <span></span>
            <span></span>
        </div>
    </div>

    <!--====== PRELOADER PART ENDS ======-->

    <!--====== Header PART START ======-->

    <?php include_once 'header.php'; ?>

    <!--====== Header PART ENDS ======-->

    <!--====== Page Banner PART START ======-->

    <section class="page_banner bg_cover" style="background-image: url(assets/images/about_bg.jpg)">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="banner_content text-center">
                        <h4 class="title">About us</h4>
                        <ul class="breadcrumb justify-content-center">
                            <li><a href="#">Home</a></li>
                            <li><a class="active" href="#">About Us</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!--====== Page Banner PART ENDS ======-->

    <!--====== About PART START ======-->

    <section class="about_area pt-80">
        <img class="shap_1" src="assets/images/shape/shape-1.png" alt="shape">
        <img class="shap_2" src="assets/images/shape/shape-2.png" alt="shape">
        <img class="shap_3" src="assets/images/shape/shape-3.png" alt="shape">
        <img class="shap_4" src="assets/images/shape/shape-4.png" alt="shape">
        
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="about_content mt-45">
                        <h3 class="about_title">We are the top learning platform</h3>
                        <p class="text">What do you think is better to receive after each lesson: a lovely looking badge or important skills you can immediately put into practice</p>
                        <p>What do you think is better to receive after each lesson: a lovely looking badge or important skills you can immediately put into practice? We thought you might choose the latter.</p>
                        <a href="#" class="main-btn">Learn More</a>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="about_image mt-50">
                        <img src="assets/images/about-1.jpg" alt="about" class="about_image-1">
                        <img src="assets/images/about-2.jpg" alt="about" class="about_image-2">
                        <img src="assets/images/about-3.jpg" alt="about" class="about_image-3">
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!--====== About PART ENDS ======-->

    <!--====== Counter PART START ======-->

    <section class="counter_area pt-80 pb-130">
        <div class="container">
            <div class="row counter_wrapper">
                <div class="col-lg-3 col-sm-6 counter_col">
                    <div class="single_counter text-center mt-50">
                        <div class="counter_icon">
                            <div class="icon_wrapper">
                                <img src="assets/images/count_icon-1.png" alt="Icon">
                            </div>
                        </div>
                        <div class="counter_content">
                            <span class="cont"><span class="counter">78</span>+</span>
                            <p>University  Faculties</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6 counter_col">
                    <div class="single_counter text-center mt-50">
                        <div class="counter_icon">
                            <div class="icon_wrapper">
                                <img src="assets/images/count_icon-2.png" alt="Icon">
                            </div>
                        </div>
                        <div class="counter_content">
                            <span class="cont"><span class="counter">5</span>k+</span>
                            <p>Total Students</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6 counter_col">
                    <div class="single_counter text-center mt-50">
                        <div class="counter_icon">
                            <div class="icon_wrapper">
                                <img src="assets/images/count_icon-3.png" alt="Icon">
                            </div>
                        </div>
                        <div class="counter_content">
                            <span class="cont"><span class="counter">400</span>k</span>
                            <p>Library Books</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6 counter_col">
                    <div class="single_counter text-center mt-50">
                        <div class="counter_icon">
                            <div class="icon_wrapper">
                                <img src="assets/images/count_icon-4.png" alt="Icon">
                            </div>
                        </div>
                        <div class="counter_content">
                            <span class="cont"><span class="counter">1200</span></span>
                            <p>Seminers Held</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!--====== Counter PART ENDS ======-->

    <!--====== About 2 PART START ======-->

    <section class="about_area_2 d-flex flex-wrap ">
        <div class="about_video bg_cover" style="background-image: url(assets/images/about_bg.jpg)">
            <div class="video">
                <a class="video_play" href="#"><i class="fa fa-play"></i></a>
            </div>
        </div>
        
        <div class="about_content_2">
            <div class="single_about_2 d-flex flex-wrap about_color_1">
                <div class="about_2_content">
                    <div class="about_2_content_wrapper">
                        <h4 class="title"><a href="#">Scholarships</a></h4>
                        <p>What do you think is better to receive after each lesson: a lovely looking </p>
                        <a href="#" class="main-btn">Learn More</a>
                    </div>
                </div>
                <div class="about_2_image bg_cover" style="background-image: url(assets/images/about-4.jpg)"></div>
            </div>
            
            <div class="single_about_2 d-flex flex-wrap about_color_2">
                <div class="about_2_content order-md-last">
                    <div class="about_2_content_wrapper">
                        <h4 class="title"><a href="#">Alumnai</a></h4>
                        <p>What do you think is better to receive after each lesson: a lovely looking </p>
                        <a href="#" class="main-btn">Learn More</a>
                    </div>
                </div>
                <div class="about_2_image bg_cover order-md-first" style="background-image: url(assets/images/about-5.jpg)"></div>
            </div>
        </div>
    </section>

    <!--====== About 2 PART ENDS ======-->

    <!--====== Why Choose Us PART START ======-->

    <section class="why_choose_area pt-120 pb-130">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="why_choose_content">
                        <div class="section_title pb-20">
                            <h3 class="main_title">Why choose us?</h3>
                            <p>What do you think is better to receive after each lesson: a lovely looking badge or important skills you can immediately put into practice.</p>
                        </div>
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="single_choose mt-30">
                                    <div class="choose_icon">
                                        <img src="assets/images/choose_icon-1.png" alt="Icon">
                                    </div>
                                    <div class="choose_content">
                                        <h5 class="title"><a href="#">Big Library</a></h5>
                                        <p>What do you think is better to receive after each lesson: a lovely looking .</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="single_choose mt-30">
                                    <div class="choose_icon">
                                        <img src="assets/images/choose_icon-2.png" alt="Icon">
                                    </div>
                                    <div class="choose_content">
                                        <h5 class="title"><a href="#">Certification</a></h5>
                                        <p>What do you think is better to receive after each lesson: a lovely looking .</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="single_choose mt-30">
                                    <div class="choose_icon">
                                        <img src="assets/images/choose_icon-3.png" alt="Icon">
                                    </div>
                                    <div class="choose_content">
                                        <h5 class="title"><a href="#">Alumnai</a></h5>
                                        <p>What do you think is better to receive after each lesson: a lovely looking .</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="single_choose mt-30">
                                    <div class="choose_icon">
                                        <img src="assets/images/choose_icon-4.png" alt="Icon">
                                    </div>
                                    <div class="choose_content">
                                        <h5 class="title"><a href="#">Abroad Student</a></h5>
                                        <p>What do you think is better to receive after each lesson: a lovely looking .</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="why_choose_image d-none d-lg-table">
            <div class="image">
                <img src="assets/images/choose_bg.png" alt="">
            </div>
        </div>
    </section>

    <!--====== Why Choose Us PART ENDS ======-->
    
    <!--====== Testimonial PART START ======-->

    <section class="testimonial_area pt-80 pb-130 bg_cover" style="background-image: url(assets/images/testimonial_bg.jpg)">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="testimonial_title mt-50">
                        <img src="assets/images/quota.png" alt="quota">
                        <h2 class="title">Success stories of students who took best from us</h2>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="testimonial_items mt-50">
                        <div class="single_testimonial">
                            <p>I found myself working in a true partnership that results in an incredible experience, and an end product that is the best. </p>
                            <h6 class="name">Arnold Holder</h6>
                            <span>Student, Language</span>
                        </div>
                        
                        <div class="single_testimonial">
                            <p>I found myself working in a true partnership that results in an incredible experience, and an end product that is the best. </p>
                            <h6 class="name">Arnold Holder</h6>
                            <span>Student, Language</span>
                        </div>
                        
                        <div class="single_testimonial">
                            <p>I found myself working in a true partnership that results in an incredible experience, and an end product that is the best. </p>
                            <h6 class="name">Arnold Holder</h6>
                            <span>Student, Language</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!--====== Testimonial PART ENDS ======-->

    <!--====== Team PART START ======-->

    <section class="team_area pt-120 pb-130">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="section_title text-center pb-50">
                        <h3 class="main_title">Top Teachers</h3>
                        <p>What do you think is better to receive after each lesson: a lovely looking badge or important skills you can immediately put into practice.</p>
                    </div>
                </div>
            </div>
            <div class="row no-gutters">
                <div class="col-lg-6 team_col_1">
                    <div class="single_team d-sm-flex flex-wrap align-items-center">
                        <img class="team_arrow" src="assets/images/left.png" alt="left">
                        <div class="team_image">
                            <img src="assets/images/team-1.jpg" alt="team">
                        </div>
                        <div class="team_content">
                            <div class="team_content_wrapper">
                                <h4 class="title"><a href="#">Andrew Flecher</a></h4>
                                <span>Business Studies</span>
                                <ul class="social">
                                    <li><a href="#"><i class="fa fa-facebook-f"></i></a></li>
                                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                    <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                                    <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="single_team d-sm-flex flex-wrap align-items-center flex-row-reverse">
                        <img class="team_arrow" src="assets/images/right.png" alt="left">
                        <div class="team_image">
                            <img src="assets/images/team-3.jpg" alt="team">
                        </div>
                        <div class="team_content">
                            <div class="team_content_wrapper">
                                <h4 class="title"><a href="#">Andrew Flecher</a></h4>
                                <span>Business Studies</span>
                                <ul class="social">
                                    <li><a href="#"><i class="fa fa-facebook-f"></i></a></li>
                                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                    <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                                    <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 team_col_2">
                    <div class="single_team d-sm-flex flex-wrap align-items-center">
                        <img class="team_arrow" src="assets/images/left.png" alt="left">
                        <div class="team_image">
                            <img src="assets/images/team-2.jpg" alt="team">
                        </div>
                        <div class="team_content">
                            <div class="team_content_wrapper">
                                <h4 class="title"><a href="#">Andrew Flecher</a></h4>
                                <span>Business Studies</span>
                                <ul class="social">
                                    <li><a href="#"><i class="fa fa-facebook-f"></i></a></li>
                                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                    <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                                    <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="single_team d-sm-flex flex-wrap align-items-center flex-row-reverse">
                        <img class="team_arrow" src="assets/images/right.png" alt="left">
                        <div class="team_image">
                            <img src="assets/images/team-4.jpg" alt="team">
                        </div>
                        <div class="team_content">
                            <div class="team_content_wrapper">
                                <h4 class="title"><a href="#">Andrew Flecher</a></h4>
                                <span>Business Studies</span>
                                <ul class="social">
                                    <li><a href="#"><i class="fa fa-facebook-f"></i></a></li>
                                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                    <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                                    <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!--====== Team PART ENDS ======-->

    <!--====== Footer PART START ======-->

    <?php include_once 'footer.php'; ?>

    <!--====== Footer PART ENDS ======-->
    
    <!--====== BACK TOP TOP PART START ======-->

    <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>

    <!--====== BACK TOP TOP PART ENDS ======-->

    









    <!--====== jquery js ======-->
    <script src="assets/js/vendor/modernizr-3.6.0.min.js"></script>
    <script src="assets/js/vendor/jquery-1.12.4.min.js"></script>

    <!--====== Bootstrap js ======-->
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/popper.min.js"></script>

    <!--====== Slick js ======-->
    <script src="assets/js/slick.min.js"></script>

    <!--====== Magnific Popup js ======-->
    <script src="assets/js/jquery.magnific-popup.min.js"></script>

    <!--====== Counter Up js ======-->
    <script src="assets/js/waypoints.min.js"></script>
    <script src="assets/js/jquery.counterup.min.js"></script>

    <!--====== Nice Select js ======-->
    <script src="assets/js/jquery.nice-select.min.js"></script>
    
    <!--====== Count Down js ======-->
    <script src="assets/js/jquery.countdown.min.js"></script>
    
    <!--====== Appear js ======-->
    <script src="assets/js/jquery.appear.min.js"></script>

    <!--====== Main js ======-->
    <script src="assets/js/main.js"></script>

</body>


<!-- Mirrored from raistheme.com/html/edustdy/edustdy/about.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 19 Jun 2020 17:18:57 GMT -->
</html>
