    <section class="header_area">
        <div class="header_top">
            <div class="container">
                <div class="header_top_wrapper d-flex justify-content-center justify-content-md-between">
                    <div class="header_top_info d-none d-md-block">
                        <ul>
                            <li><img src="assets/images/call.png" alt="call"><a href="#">+234 801 2345 6789</a></li>
                            <li><img src="assets/images/mail.png" alt="mail"><a href="#">info@swiftonlinelearning.com</a></li>
                        </ul>
                    </div>
                    <div class="header_top_login">
                        <?php
                        if(isset($_SESSION['type']))
                        {
                            echo '<ul>
                            
                            <li><a class="main-btn" href="auth/logout.php"><i class="fa fa-user-o"></i> Log Out</a></li>
                        </ul>';
                        }
                        else
                        {
                            echo '<ul>
                            <li><a href="signup.php">Create An Account</a></li>
                            <li><a class="main-btn" href="auth/login.php"><i class="fa fa-user-o"></i> Log In</a></li>
                        </ul>';
                        }
                        ?>
                        
                    </div>
                </div>
            </div>
        </div>

        <div class="header_menu">
            <div class="container">
                <nav class="navbar navbar-expand-lg">
                    <a class="navbar-brand" href="index.php">
                        <img src="assets/images/logo.png" alt="logo">
                    </a>
                    
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="toggler-icon"></span>
                        <span class="toggler-icon"></span>
                        <span class="toggler-icon"></span>
                    </button>

                    <div class="collapse navbar-collapse sub-menu-bar" id="navbarSupportedContent">
                        <ul class="navbar-nav m-auto">
                            <?php
                                if(!isset($_SESSION['type'])){
                                    echo '<li>
                                    <a href="index.php">Home</a>
                                    </li>
                                    <li>
                                        <a href="about.php">About</a>
                                    </li>
                                    <li>
                                        <a href="courses.php">Courses</a>
                                    </li>

                                    <li>
                                        <a href="contact.php">Contact</a>
                                    </li>';
                                }
                                elseif(isset($_SESSION['type'])){
                                    echo '<li>
                                    <a href="index.php">Home</a>
                                    </li>
                                    
                                    <li>
                                        <a href="courses.php">Courses</a>
                                    </li>
                                    <li>
                                        <a href="create_course.php">Create Courses</a>
                                    </li>';
                                }
                            ?>
                        </ul>
                    </div>
                    
                    <div class="navbar_meta">
                        <ul>
<!--
                            <li>
                                <a id="search" href="#"><img src="assets/images/search.png" alt="search"></a>
                                <div class="search_bar">
                                    <input type="text" placeholder="Search">
                                    <button><i class="fa fa-search"></i></button>
                                </div>
                            </li>
-->
                        </ul>
                    </div>
                </nav>
            </div>
        </div>
    </section>