<?php
if(!isset($_SESSION['type']))
{
	header('location:auth/login.php');
}
$user_id = $_SESSION["user_id"];




$query2 = "
SELECT * FROM user_details 
WHERE user_id = '$user_id'
";
$statement2 = $connect->prepare($query2);
$statement2->execute();
$result2 = $statement2->fetchAll();
foreach($result2 as $row2)
{
    $user_type = $row2['user_type'];
    $user_name = $row2['user_name'];
    $user_email = $row2['user_email'];
    $user_phone = $row2['user_phone'];
    $user_sex = $row2['user_sex'];
    $user_address = $row2['user_address'];
    $user_occupation = $row2['user_occupation'];
    $user_state = $row2['user_state'];
    $user_type = $row2['user_type'];
}


