<?php
//error_reporting('0');
//database_connection.php

$connect = new PDO('mysql:host=localhost;dbname=learning', 'root', '');
session_start();

?>