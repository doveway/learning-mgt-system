<?php
//error_reporting(0);
include('database_connection.php');
if(!isset($_SESSION['type']))
{
	header('location:login.php');
}
if(isset($_POST["submit"])){
    
    $user_inputPounds = $_POST['user_inputPounds'];
    $user_inputKilograms = $_POST['user_inputKilograms'];
    $user_order_description = $_POST['user_order_description'];
    $user_est_price = $user_inputPounds * 4.99;
    $user_id = $_SESSION["user_id"];
    $message ='';
    
    try {
    

    $query1 = "SELECT * FROM user_orders WHERE user_id = '$user_id' AND user_inputPounds = '$user_inputPounds' AND user_order_description = '$user_order_description' ";
 
    $stmt = $connect->prepare($query1);
    $stmt->execute();
    $num = $stmt->rowCount();
    if($num<1){
        $sql = "INSERT INTO user_orders (user_id,user_inputPounds,user_inputKilograms,user_est_price,user_order_description, user_type,user_order_actual_fee,user_shipping_info1,user_shipping_info1_date, user_shipping_info2, user_shipping_info2_date, user_shipping_info3, user_shipping_info3_date, user_shipping_info4, user_shipping_info4_date, order_date_created)
        VALUES ('".$user_id."','".$_POST["user_inputPounds"]."', '".$_POST["user_inputKilograms"]."', '".$user_est_price."', '".$_POST["user_order_description"]."','user','0', '', '', '', '', '', '', '', '', now())";
        if ($connect->query($sql)) {
            $message =  '<div class="alert alert-success">Shipping order created</div>';
        }
        else{
            $message = '<div class="alert alert-danger">Error: Order was not created, please try again.</div>';
        }
    }else
    {
         $message = '<div class="alert alert-danger">Error: There is an order with exact weight and description.</div>';
    }
    
    $dbh = null;
    }
    catch(PDOException $e)
    {
    echo $e->getMessage();
    }
    
    }
?>
<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no, viewport-fit=cover">

    <!-- favicons -->
    <!-- <link rel="apple-touch-icon" href="img/favicon-apple.png">
    <link rel="icon" href="img/favicon.png"> -->




    <!-- Material design icons CSS -->
    <link rel="stylesheet" href="vendor/materializeicon/material-icons.css">

    <!-- aniamte CSS -->
    <link rel="stylesheet" href="vendor/animatecss/animate.css">

    <!-- swiper carousel CSS -->
    <link rel="stylesheet" href="vendor/swiper/css/swiper.min.css">

    <!-- daterange CSS -->
    <link rel="stylesheet" href="vendor/bootstrap-daterangepicker-master/daterangepicker.css">

    <!-- footable CSS -->
    <link rel="stylesheet" href="vendor/footable-bootstrap/css/footable.bootstrap.min.css">

    <!-- jvector map CSS -->
    <link rel="stylesheet" href="vendor/jquery-jvectormap/jquery-jvectormap-2.0.3.css">

    <!-- app CSS -->
    <link id="theme" rel="stylesheet" href="css/purplesidebar.css" type="text/css">

    <title>MyInstantshippers::Profile</title>
</head>

<body class="fixed-header sidebar-right-close">
    
    <div class="wrapper">
        <!-- main header -->
        <?php include('header.php'); ?>
        <!-- main header ends -->
        <!-- sidebar left -->
        <?php include('left-navbar.php'); ?>
        <!-- sidebar left ends -->
        

        <!-- content page title -->
        <div class="container-fluid bg-light-opac">
            <div class="row">
                <div class="container my-3 main-container">
                    <div class="row align-items-center">
                        <div class="col">
                            <h2 class="content-color-primary page-title">User Orders</h2>
                            <p class="content-color-secondary page-sub-title"></p>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
        <!-- content page title ends -->

        <!-- content page -->
        <div class="container mt-4 main-container">
			<div class="card mb-4">
				<div class="card-header border-bottom">
					<div class="media">
						<div class="icon-circle icon-40 bg-light-primary mr-3">
							<i class="material-icons">business</i>
						</div>
						<div class="media-body">
							<h6 class="my-0 content-color-primary">Create an Order</h6>
							<p class="small mb-0">Create an order to ship your goods to Nigeria</p>
						</div>
					</div>
				</div>
                <div class="card-body">
                    <div class="row justify-content-center">
                        <div class="col-md-10 ">
                        	<form method="post" action="" id="edit_profile_form">                       	
                            
                            <?php  
                            if(isset($_POST["submit"]))
                            {
                                echo $message; 
                            }
                            ?>
					       	<div class="form-group row">
                                <div class="col-lg-6 col-md-6">
                                    <label>Weight in Pounds</label>
                                    <input type="number" step="0.01" name="user_inputPounds" id="user_inputPounds" class="form-control" placeholder="Pounds(lbs)"  
                                    oninput="weightConverter(this.id,this.value)" onchange="weightConverter(this.id,this.value)" required>
                                       
                                    
                                        
                                     <!-- <p>
                                        <label>Pounds</label>
                                        <input id="inputPounds" type="number" placeholder="Pounds"
                                        oninput="weightConverter(this.value)" onchange="weightConverter(this.value)">
                                        </p>
                                        <p>Grams: <span id="outputGrams"></span>
                                    </p>  -->
                                </div>
                                <div class="col-lg-6 col-md-6">
                                <label>Weight in Kilograms</label>
                                    <input type="number" step="0.01" name="user_inputKilograms" id="user_inputKilograms" class="form-control" placeholder="Kilograms(kg)"  
                                    oninput="weightConverter(this.id,this.value)" onchange="weightConverter(this.id,this.value)">
                                </div>
                                
                                
                            </div>
                                                                      
                            <br>

                            <div class="form-group row">
                                <div class="col-lg-12 col-md-12">
                                    <label>Description(What the package contains)</label>
                                    <textarea class="form-control" name="user_order_description" id="user_order_description" placeholder="E.g 2 iPhones and 1 shoe"  rows="4" required></textarea>
                                </div>
                            </div>
                            <br>
                            <p><strong>Estimated Shipping Fee:</strong> <span style="font-weight:bold" name="user_est_price" id="user_est_price"></span></p> 
  
                            <div class="card-footer">
                                <input type="hidden" name="user_est_price" id="user_est_price" />
                                <button type="reset" class="btn btn-secondary">Cancel</button>
                                <input type="submit" value=" Create Order " name="submit"  class="btn btn-primary pink-gradient"/>
                            </div>
                            </form>
                            



<script>
function weightConverter(source,valNum) {
  valNum = parseFloat(valNum);
  var user_inputPounds = document.getElementById("user_inputPounds");
  var user_inputKilograms = document.getElementById("user_inputKilograms");
  var inputOunces = document.getElementById("inputOunces");
  var inputGrams = document.getElementById("inputGrams");
  var inputStones = document.getElementById("inputStones");
  document.getElementById("user_est_price").innerHTML = '$'+(user_inputPounds.value * 4.99).toFixed(2);
  //document.getElementById("price").innerHTML = inputPounds * 4.99;
  //var price = document.getElementById("price");
  if (source=="user_inputPounds") {
    user_inputKilograms.value=(valNum/2.2046).toFixed(2);
    inputOunces.value=(valNum*16).toFixed(2);
    inputGrams.value=(valNum/0.0022046).toFixed();
    inputStones.value=(valNum*0.071429).toFixed(3);
    user_est_price.value=(valNum*2).toFixed(2);
  }
  if (source=="user_inputKilograms") {
    user_inputPounds.value=(valNum*2.2046).toFixed(2);
    inputOunces.value=(valNum*35.274).toFixed(2);
    inputGrams.value=(valNum*1000).toFixed();
    inputStones.value=(valNum*0.1574).toFixed(3);
    // price.value=(valNum*2).toFixed(2);
  }
  if (source=="inputOunces") {
    user_inputPounds.value=(valNum*0.062500).toFixed(4);
    inputKilograms.value=(valNum/35.274).toFixed(4);
    inputGrams.value=(valNum/0.035274).toFixed(1);
    inputStones.value=(valNum*0.0044643).toFixed(4);
  }
  if (source=="inputGrams") {
    inputPounds.value=(valNum*0.0022046).toFixed(4);
    inputKilograms.value=(valNum/1000).toFixed(4);
    inputOunces.value=(valNum*0.035274).toFixed(3);
    inputStones.value=(valNum*0.00015747).toFixed(5);
  }
  if (source=="inputStones") {
    inputPounds.value=(valNum*14).toFixed(1);
    inputKilograms.value=(valNum/0.15747).toFixed(1);
    inputOunces.value=(valNum*224).toFixed();
    inputGrams.value=(valNum/0.00015747).toFixed();
  }

}
</script>




                        </div>
                    </div>
				</div>
			</div>
		</div>
        <!-- content page ends -->

    </div>
	<?php include('footer.php'); ?>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="vendor/bootstrap-4.1.3/js/bootstrap.min.js"></script>

    <!-- Cookie jquery file -->
    <script src="vendor/cookie/jquery.cookie.js"></script>

    <!-- sparklines chart jquery file -->
    <script src="vendor/sparklines/jquery.sparkline.min.js"></script>

    <!-- Circular progress gauge jquery file -->
    <script src="vendor/circle-progress/circle-progress.min.js"></script>

    <!-- Swiper carousel jquery file -->
    <script src="vendor/swiper/js/swiper.min.js"></script>

    <!-- Chart js jquery file -->
    <script src="vendor/chartjs/Chart.bundle.min.js"></script>
    <script src="vendor/chartjs/utils.js"></script>

    <!-- Footable jquery file -->
    <script src="vendor/footable-bootstrap/js/footable.min.js"></script>

    <!-- datepicker jquery file -->
    <script src="vendor/bootstrap-daterangepicker-master/moment.js"></script>
    <script src="vendor/bootstrap-daterangepicker-master/daterangepicker.js"></script>

    <!-- jVector map jquery file -->
    <script src="vendor/jquery-jvectormap/jquery-jvectormap.js"></script>
    <script src="vendor/jquery-jvectormap/jquery-jvectormap-world-mill-en.js"></script>

    <!-- circular progress file -->
    <script src="vendor/circle-progress/circle-progress.min.js"></script>

    <!-- Application main common jquery file -->
    <script src="js/main.js"></script>

	<!-- page specific script -->
	<!-- <script>
$(document).ready(function(){
	$('#edit_profile_form').on('submit', function(event){
		event.preventDefault();
		if($('#user_new_password').val() != '')
		{
			if($('#user_new_password').val() != $('#user_re_enter_password').val())
			{
				$('#error_password').html('<label class="text-danger">Password Not Match</label>');
				return false;
			}
			else
			{
				$('#error_password').html('');
			}
		}
		$('#edit_prfile').attr('disabled', 'disabled');
		var form_data = $(this).serialize();
		$('#user_re_enter_password').attr('required',false);
		$.ajax({
			url:"edit_profile.php",
			method:"POST",
			data:form_data,
			success:function(data)
			{
				$('#edit_prfile').attr('disabled', false);
				$('#user_new_password').val('');
				$('#user_re_enter_password').val('');
				$('#message').html(data);
			}
		})
	});
});
</script> -->

</body>
</html>
