<!DOCTYPE HTML>
<html>
<head>
    <title>Deshoerack::Admin Update</title>
     
    <!-- Latest compiled and minified Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />
         
</head>
<body>
 
    <!-- container -->
    <div class="container">
  
        <div class="page-header">
            <h1>Update Order</h1>
        </div>
     
        <!-- PHP read record by ID will be here -->
        <?php
// get passed parameter value, in this case, the record ID
// isset() is a PHP function used to verify if a value is there or not
$user_order_id=isset($_GET['user_order_id']) ? $_GET['user_order_id'] : die('ERROR: Order ID not found.');
 
//include database connection
include 'database_connection.php';
 
// read current record's data
try {
    // prepare select query
    $query = "SELECT * FROM user_orders WHERE user_order_id = ? LIMIT 0,1";
    $stmt = $connect->prepare( $query );
     
    // this is the first question mark
    $stmt->bindParam(1, $user_order_id);
     
    // execute our query
    $stmt->execute();
     
    // store retrieved row to a variable
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
     
    // values to fill up our form
    $user_inputPounds = $row['user_inputPounds'];
    $user_est_price = $row['user_est_price'];
    $user_order_description = $row['user_order_description'];
}
 
// show error
catch(PDOException $exception){
    die('ERROR: ' . $exception->getMessage());
}
?>
 
        
        <!-- PHP post to update record will be here -->
        <?php
 
// check if form was submitted
if($_POST){
     
    try{
     
        // write update query
        // in this case, it seemed like we have so many fields to pass and 
        // it is better to label them and not use question marks
        $query = "UPDATE user_orders 
                    SET user_inputPounds=:user_inputPounds, user_est_price=:user_est_price, user_order_description=:user_order_description 
                    WHERE user_order_id = :user_order_id";
 
        // prepare query for excecution
        $stmt = $connect->prepare($query);
 
        // posted values
        $user_inputPounds=htmlspecialchars(strip_tags($_POST['user_inputPounds']));
        $user_est_price= $user_inputPounds*4.99;
        $user_order_description=htmlspecialchars(strip_tags($_POST['user_order_description']));
 
        // bind the parameters
        $stmt->bindParam(':user_inputPounds', $user_inputPounds);
        $stmt->bindParam(':user_est_price', $user_est_price);
        $stmt->bindParam(':user_order_description', $user_order_description);
        $stmt->bindParam(':user_order_id', $user_order_id);
         
        // Execute the query
        if($stmt->execute()){
            echo "<div class='alert alert-success'>Record was updated.</div>";
        }else{
            echo "<div class='alert alert-danger'>Unable to update record. Please try again.</div>";
        }
         
    }
     
    // show errors
    catch(PDOException $exception){
        die('ERROR: ' . $exception->getMessage());
    }
}
?>

<!-- HTML form to update record will be here -->
 
<!--we have our html form here where new record information can be updated-->
<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"] . "?user_order_id={$user_order_id}");?>" method="post">
    <table class='table table-hover table-responsive table-bordered'>
        <tr>
            <td>Weight(Pounds)</td>
            <td><input type="number" step="0.01" name="user_inputPounds" id="user_inputPounds" value="<?php echo htmlspecialchars($user_inputPounds, ENT_QUOTES);  ?>" class='form-control' oninput="weightConverter(this.id,this.value)" onchange="weightConverter(this.id,this.value)" required /></td>
        </tr>
        <tr>
            <td>Estimated Fee</td>
            <td><input type='number' step="0.01" name="user_est_price" id="user_est_price" value="<?php echo number_format(htmlspecialchars($user_est_price, ENT_QUOTES),2);  ?>" class='form-control'  readonly /></td>
        </tr>
        <tr>
            <td>Updated Fee</td>
            <td><span style="font-weight:bold" name="user_est_price2" id="user_est_price2"></span></td>
        </tr>
        <tr>
            <td>Description</td>
            <td><textarea name='user_order_description' class='form-control'><?php echo htmlspecialchars($user_order_description, ENT_QUOTES);  ?></textarea></td>
        </tr>
        
        
        <tr>
            <td></td>
            <td>
                <input type='submit' value='Save Changes' class='btn btn-primary' />
                <a href='user_orders.php' class='btn btn-danger'>Back to Orders</a>
            </td>
        </tr>
    </table>
</form>
         
    </div> <!-- end .container -->
     
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
   
<!-- Latest compiled and minified Bootstrap JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script>
function weightConverter(source,valNum) {
  valNum = parseFloat(valNum);
  var user_inputPounds = document.getElementById("user_inputPounds");
  var user_inputKilograms = document.getElementById("user_inputKilograms");
  var inputOunces = document.getElementById("inputOunces");
  var inputGrams = document.getElementById("inputGrams");
  var inputStones = document.getElementById("inputStones");
  document.getElementById("user_est_price2").innerHTML = '$'+(user_inputPounds.value * 4.99).toFixed(2);
  //document.getElementById("price").innerHTML = inputPounds * 4.99;
  //var price = document.getElementById("price");
  if (source=="user_inputPounds") {
    user_inputKilograms.value=(valNum/2.2046).toFixed(2);
    inputOunces.value=(valNum*16).toFixed(2);
    inputGrams.value=(valNum/0.0022046).toFixed();
    inputStones.value=(valNum*0.071429).toFixed(3);
    user_est_price2.value=(valNum*2).toFixed(2);
  }
  if (source=="user_inputKilograms") {
    user_inputPounds.value=(valNum*2.2046).toFixed(2);
    inputOunces.value=(valNum*35.274).toFixed(2);
    inputGrams.value=(valNum*1000).toFixed();
    inputStones.value=(valNum*0.1574).toFixed(3);
    // price.value=(valNum*2).toFixed(2);
  }
  if (source=="inputOunces") {
    user_inputPounds.value=(valNum*0.062500).toFixed(4);
    inputKilograms.value=(valNum/35.274).toFixed(4);
    inputGrams.value=(valNum/0.035274).toFixed(1);
    inputStones.value=(valNum*0.0044643).toFixed(4);
  }
  if (source=="inputGrams") {
    inputPounds.value=(valNum*0.0022046).toFixed(4);
    inputKilograms.value=(valNum/1000).toFixed(4);
    inputOunces.value=(valNum*0.035274).toFixed(3);
    inputStones.value=(valNum*0.00015747).toFixed(5);
  }
  if (source=="inputStones") {
    inputPounds.value=(valNum*14).toFixed(1);
    inputKilograms.value=(valNum/0.15747).toFixed(1);
    inputOunces.value=(valNum*224).toFixed();
    inputGrams.value=(valNum/0.00015747).toFixed();
  }

}
</script>

 
</body>
</html>