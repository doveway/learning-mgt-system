<div class="sidebar sidebar-left">
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a href="javascript:void(0);" class="nav-link"><i class="material-icons icon"></i> <span>Dashboard</span></a>
                </li>
                <!-- <li class="nav-item">
                    <a href="index.php" class="nav-link"><i class="material-icons icon">filter_none</i> <span>Dashboard</span></a>
                </li> -->
                <li class="nav-item">
                    <a href="create_course.php" class="nav-link"><i class="material-icons icon">person</i> <span>Create A Course</span></a>
                </li>

                <li class="nav-item">
                    <a href="../auth/logout.php" class="nav-link"><i class="material-icons icon">exit_to_app</i> <span>Logout</span></a>
                </li>
            </ul>
        </div>