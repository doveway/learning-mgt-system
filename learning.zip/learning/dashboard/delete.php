<?php
// include database connection
include 'database_connection.php';
 
try {
     
    // get record ID
    // isset() is a PHP function used to verify if a value is there or not
    $user_order_id=isset($_GET['user_order_id']) ? $_GET['user_order_id'] : die('ERROR: Order ID not found.');
 
    // delete query
    $query = "DELETE FROM user_orders WHERE user_order_id = ?";
    $stmt = $connect->prepare($query);
    $stmt->bindParam(1, $user_order_id);
     
    if($stmt->execute()){
        // redirect to read records page and 
        // tell the user record was deleted
        header('Location: user_orders.php?action=deleted');
    }else{
        die('Unable to delete record.');
    }
}
 
// show error
catch(PDOException $exception){
    die('ERROR: ' . $exception->getMessage());
}
?>