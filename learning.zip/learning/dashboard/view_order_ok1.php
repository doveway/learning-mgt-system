<?php

//view_order.php

if(isset($_GET["pdf"]) && isset($_GET['user_order_id']) && isset($_GET['user_id']))
{
	require_once 'pdf.php';
	include('database_connection.php');
	include('function.php');
	if(!isset($_SESSION['type']))
	{
		header('location:login.php');
	}
	$output = '';
	$user_order_id = $_GET["user_order_id"];
	$statement = $connect->prepare("
		SELECT * FROM user_details
		WHERE user_id = :user_id
		LIMIT 1
	");
	$statement->execute(
		array(
			':user_id'       =>  $_GET["user_id"]
		)
	);
	$result = $statement->fetchAll();
	foreach($result as $row)
	{
		$output .= '
		<table width="100%" border="1" cellpadding="5" cellspacing="0">
			<tr>
				<td colspan="2" align="center" style="font-size:18px"><b>Invoice</b></td>
			</tr>
			<tr>
				<td colspan="2">
				<table width="100%" cellpadding="5">
					<tr>
						<td width="65%">
							To,<br />
							<b>RECEIVER (BILL TO)</b><br />
							Name : '.$row["user_name"].'<br />	
							Billing Address : '.$row["user_address"].'<br />
						</td>
						<td width="35%">
							Reverse Charge<br />
							Invoice No. : '.$user_order_id.'<br />
							Invoice Date : '.$row["user_name"].'<br />
						</td>
					</tr>
				</table>
				<br />
				<table width="100%" border="1" cellpadding="5" cellspacing="0">
					<tr>
						<th rowspan="2">Sr No.</th>
						<th rowspan="2">Product</th>
						<th rowspan="2">Quantity</th>
						<th rowspan="2">Price</th>
						<th rowspan="2">Actual Amt.</th>
						<th colspan="2">Tax (%)</th>
						<th rowspan="2">Total</th>
					</tr>
					<tr>
						<th>Rate</th>
						<th>Amt.</th>
					</tr>
		';
		
	}
	$pdf = new Pdf();
	$file_name = 'Order-'.$row["user_id"].'.pdf';
	$pdf->loadHtml($output);
	$pdf->render();
	$pdf->stream($file_name, array("Attachment" => false));
}

?>