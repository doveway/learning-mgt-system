<?php
//database_connection.php

$connect = new PDO('mysql:host=localhost;dbname=myinstan_dbVigo22', 'myinstan_cargo55', 'xX34rTy9@U');
session_start();
?>