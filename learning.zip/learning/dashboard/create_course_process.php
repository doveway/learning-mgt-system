<?php
include('../database_connection.php');
$user_id = $_SESSION["user_id"];
        $connect->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); // <== add this line
        $sql = "INSERT INTO courses (course_tutor, course_title	, course_price, course_category, course_overview, no_of_lectures, course_duration, course_test, course_level, course_language, image_link, date_course_created)
        VALUES ('".$_POST["course_tutor"]."', '".$_POST["course_title"]."', '".$_POST["course_price"]."', '".$_POST["course_category"]."', '".$_POST["course_overview"]."', '".$_POST["no_of_lectures"]."', '".$_POST["course_duration"]."', '".$_POST["course_test"]."', '".$_POST["course_level"]."', '".$_POST["course_language"]."', '', now())";
        if ($connect->query($sql)) {
            echo '<div class="alert alert-success">Course successfully added. <br> </div>';
           
            $valid_extensions = array('jpeg', 'jpg', 'png', 'gif', 'bmp' , 'pdf' , 'doc' , 'ppt'); // valid extensions
            $path = 'uploads/'; // upload directory

            if($_FILES['image'])
            {
            $img = $_FILES['image']['name'];
            $tmp = $_FILES['image']['tmp_name'];

            // get uploaded file's extension
            $ext = strtolower(pathinfo($img, PATHINFO_EXTENSION));

            // can upload same image using rand function
            $pid=$connect->lastInsertId();
            $rand = rand(1000,10000000000000);
            $final_image = $rand.$img;
            //echo 'final image: '.$final_image;

            // check's valid format
            if(in_array($ext, $valid_extensions)) 
            { 
            $path = $path.strtolower($final_image);
            //echo '<br>path: '.$path;

            if(move_uploaded_file($tmp,$path)) 
            {
                $query = "
                UPDATE courses SET 
                    image_link = '".$final_image."'
                    WHERE id = '$pid'
                ";

                $statement = $connect->prepare($query);
                $statement->execute();
                
            }
            } 
            else 
            {
            echo 'invalid';
            }
            }
        }
        else{
            echo "<script type= 'text/javascript'>alert('Course NOT added. Please try again');</script>";
        }
        



//
//include('../database_connection.php');
//$user_id = $_SESSION["user_id"];
//        $connect->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); // <== add this line
//        $sql = "INSERT INTO houses (property_name, property_address, no_of_bedrooms, no_of_bathrooms, no_of_garages, price, sqft, property_status, property_id, property_type, property_description, date_added)
//        VALUES ('".$_POST["property_name"]."', '".$_POST["property_address"]."', '".$_POST["no_of_bedrooms"]."', '".$_POST["no_of_bathrooms"]."', ".$_POST["no_of_garages"].", '".$_POST["price"]."', '".$_POST["sqft"]."', '".$_POST["property_status"]."', '".$_POST["property_id"]."', '".$_POST["property_type"]."', '".$_POST["property_description"]."', now())";
//        if ($connect->query($sql)) {
//            echo '<div class="alert alert-success">Property successfully added. <br> </div>';
//           
//            
//        }
//        else{
//            echo "<script type= 'text/javascript'>alert('Property NOT added. Please try again');</script>";
//        }
//        
    
?>