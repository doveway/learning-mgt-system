<header class="main-header">
            <div class="container-fluid">
                <div class="row align-items-center">
                    <div class="col-auto pl-0">
                        <button class="btn pink-gradient btn-icon" id="left-menu"><i class="material-icons">widgets</i></button>
                        <a href="index.html" class="logo"><!--<img src="img/logo-icon.png" alt="">--><span class="text-hide-xs"><b></b></span></a>
                        
                    </div>
                    <div class="col text-center p-xs-0">
                        <ul class="time-day">
                            
                        </ul>

                    </div>
                    <div class="col-auto pr-0">
                        <button class="btn btn-link text-hide-md header-color-secondary font-small px-0" type="button"><i class="material-icons">text_format</i></button>
                        <button class="btn btn-link text-hide-md header-color-secondary font-big px-0 mr-3" type="button"><i class="material-icons">text_format</i></button>

                        <button class="btn btn-search btn-icon header-color-secondary" type="button"><i class="material-icons">search</i></button>

                        <div class="dropdown d-inline-block">
                            <a class="btn header-color-secondary username" href="#" role="button" id="dropdownMenuLink" aria-haspopup="true" aria-expanded="false">
                                <figure class="userpic"><img src="img/user1.png" alt=""></figure>
                                <h5 class="text-hide-xs">
                                    <small class="header-color-secondary">Welcome,</small>
                                    <span class="header-color-primary"><?php echo $_SESSION["user_name"]; ?></span>
                                </h5>
                            </a>
                            
                        </div>

                    </div>
                </div>
            </div>
        </header>