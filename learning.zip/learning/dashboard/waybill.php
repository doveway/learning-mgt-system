<?php

//view_order.php

if(isset($_GET["pdf"]) && isset($_GET['user_order_id']) && isset($_GET['user_id']))
{
	require_once 'pdf.php';
	include('database_connection.php');
	include('function.php');
	if(!isset($_SESSION['type']))
	{
		header('location:login.php');
	}
	$output = '';
	$user_order_id = $_GET["user_order_id"];
	$date_created = $_GET["order_date_created"];
	$order_date_created = date("d-m-Y",strtotime($date_created));
	$statement = $connect->prepare("
		SELECT * FROM user_details
		WHERE user_id = :user_id
		LIMIT 1
	");
	$statement->execute(
		array(
			':user_id'       =>  $_GET["user_id"]
		)
	);
	$result = $statement->fetchAll();
	foreach($result as $row)
	{
		$output .= '
		<table width="100%" border="1" cellpadding="5" cellspacing="0">
			<tr>
				<td colspan="2" align="center" style="font-size:18px"><b>Waybill</b></td>
			</tr>
			<tr>
				<td colspan="2">
				<table width="100%" cellpadding="5">
					<tr>
						<td width="65%">
							
							<b>LOGO GOES HERE</b><br />
							
						</td>
						<td width="35%">
							MyInstantShippers<br /> Katty, Texas <br> UNITED STATES <br>
							Tel. : +1(281)571-3303<br />
						</td>
					</tr>
				</table>
				<br />
				<table width="100%" border="1" cellpadding="5" cellspacing="0">
					<tr>
						<th rowspan="2">S/No.</th>
						<th rowspan="2">Description</th>
						<th rowspan="2">Weight(Pounds)</th>
						
						
						
					</tr>
					<tr>
                
						
					</tr>
		';

		$statement = $connect->prepare("
			SELECT * FROM user_orders 
			WHERE user_order_id = '$user_order_id'
		");
		$statement->execute(
			array(
				':user_order_id'       =>  $_GET["user_order_id"],
				
			)
		);
		$order_result = $statement->fetchAll();
		$count = 0;
		foreach($order_result as $order_row)
		{
			$count = $count + 1;
			
			$output .= '
				<tr>
					<td>'.$count.'</td>
					<td>'.$order_row['user_order_description'].'</td>
					<td>'.$order_row['user_inputPounds'].' lbs</td>
					
					
	
                </tr>
                
                
                
			';
		}
		$output .= '
		
		';
		$output .= '
						</table>
						<br />
						<br />
						<br />
						<br />
						<br />
						<br />
                        
                        <hr>
                        <p>Notes
                        <br><h3> '.$row["user_address"].'</h3>
                        </p>
						<br />
						<br />
						<br />
                    </td>
                    
				</tr>
			</table>
		';
		
	}
	$pdf = new Pdf();
	$file_name = 'Waybill-'.$row["user_id"].'.pdf';
	$pdf->loadHtml($output);
	$pdf->render();
	$pdf->stream($file_name, array("Attachment" => false));
}

?>