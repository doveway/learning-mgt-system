<footer class="border-top">
        <div class="row">
            <div class="col-12 col-sm-6"></div>
            <div class="col-12 col-sm-6 text-right"><a href="#" class="content-color-secondary">Privacy Policy</a> | <a href="#" class="content-color-secondary">Terms of use</a></div>
        </div>
    </footer>