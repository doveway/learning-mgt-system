<?php
include('../database_connection.php');
if(!isset($_SESSION['type']))
{
	header('location:login.php');
}
$query = "
SELECT * FROM user_details 
WHERE user_id = '".$_SESSION["user_id"]."'
";
$statement = $connect->prepare($query);
$statement->execute();
$result = $statement->fetchAll();
$name = '';
$email = '';
$phone = '';
$sex = '';
$address = '';
$user_id = '';
foreach($result as $row)
{
	$name = $row['user_name'];
    $email = $row['user_email'];
    $phone = $row['user_phone'];
    $sex = $row['user_sex'];
	$address = $row['user_address'];
}
?>
<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no, viewport-fit=cover">

    <!-- favicons -->
    <!-- <link rel="apple-touch-icon" href="img/favicon-apple.png">
    <link rel="icon" href="img/favicon.png"> -->




    <!-- Material design icons CSS -->
    <link rel="stylesheet" href="vendor/materializeicon/material-icons.css">

    <!-- aniamte CSS -->
    <link rel="stylesheet" href="vendor/animatecss/animate.css">

    <!-- swiper carousel CSS -->
    <link rel="stylesheet" href="vendor/swiper/css/swiper.min.css">

    <!-- daterange CSS -->
    <link rel="stylesheet" href="vendor/bootstrap-daterangepicker-master/daterangepicker.css">

    <!-- footable CSS -->
    <link rel="stylesheet" href="vendor/footable-bootstrap/css/footable.bootstrap.min.css">

    <!-- jvector map CSS -->
    <link rel="stylesheet" href="vendor/jquery-jvectormap/jquery-jvectormap-2.0.3.css">

    <!-- app CSS -->
    <link id="theme" rel="stylesheet" href="css/purplesidebar.css" type="text/css">

    <title>MyInstantshippers::Profile</title>
</head>

<body class="fixed-header sidebar-right-close">
    
    <div class="wrapper">
        <!-- main header -->
        <?php include('header.php'); ?>
        <!-- main header ends -->
        <!-- sidebar left -->
        <?php include('left-navbar.php'); ?>
        <!-- sidebar left ends -->
        

        <!-- content page title -->
        <div class="container-fluid bg-light-opac">
            <div class="row">
                <div class="container my-3 main-container">
                    <div class="row align-items-center">
                        <div class="col">
                            <h2 class="content-color-primary page-title">Profile</h2>
                            <p class="content-color-secondary page-sub-title">Update your profile details</p>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
        <!-- content page title ends -->

        <!-- content page -->
        <div class="container mt-4 main-container">
			<div class="card mb-4">
				<div class="card-header border-bottom">
					<div class="media">
						<div class="icon-circle icon-40 bg-light-primary mr-3">
							<i class="material-icons">business</i>
						</div>
						<div class="media-body">
							<h6 class="my-0 content-color-primary">Personal Info</h6>
							<p class="small mb-0">Information will be used for shipping your orders</p>
						</div>
					</div>
				</div>
                <div class="card-body">
                    <div class="row justify-content-center">
                        <div class="col-md-10 ">
                        	<form method="post" id="edit_profile_form">    
                        	<span id="message"></span>
                        	<div class="form-group row">
                                <div class="col-lg-6 col-md-6">
                                    <label>Full Name</label>
                                    <input type="text" name="user_name" id="user_name" class="form-control" value="<?php echo $name; ?>" required>
                                </div>
                                <div class="col-lg-6 col-md-6">
                                    <label>Email</label>
                                    <input type="email" name="user_email" id="user_email" class="form-control" value="<?php echo $email; ?>"  required>
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-lg-6 col-md-6">
                                    <label>Phone No.</label>
                                    <input type="text" name="user_phone" id="user_phone" class="form-control" value="<?php echo $phone; ?>" required>
                                </div>
                                <div class="col-lg-6 col-md-6">
                                    <label>Sex</label>
                                    <select class="custom-select" name="user_sex" id="user_sex">
                                        <option value="<?php echo $sex; ?>"><?php echo $sex; ?></option>
                                        <option value="Male">Male</option>
                                        <option value="Female">Female</option>
                                    </select>
                                </div>
                            </div>
                                               
                            <div class="form-group row">
                                <div class="col-lg-12 col-md-12">
                                    <label>Address</label>
                                    <textarea class="form-control" name="user_address" id="user_address"  rows="4"><?php echo $address; ?></textarea>
                                </div>
                            </div>
                            <br>
                            <label style="color:red !important;">Leave Password blank if you do not want to change it</label>
                            <div class="form-group row">
                                <div class="col-lg-6 col-md-6">
                                    <label>Password</label>
                                    <input type="password" name="user_new_password" id="user_new_password" class="form-control">
                                </div>
                                <div class="col-lg-6 col-md-6">
                                    <label>Confirm Password</label>
									<input type="password" name="user_re_enter_password" id="user_re_enter_password" class="form-control">
									<span id="error_password"></span>
                                </div>
                            </div>
                            <div class="card-footer">
                                <button type="reset" class="btn btn-secondary">Cancel</button>
                                <input type="submit" class="btn btn-success float-right" name="edit_prfile" id="edit_prfile" value="Edit">
                            </div>
                            </form>
                            
                        </div>
                    </div>
				</div>
			</div>
		</div>
        <!-- content page ends -->

    </div>
	<?php include('footer.php'); ?>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="vendor/bootstrap-4.1.3/js/bootstrap.min.js"></script>

    <!-- Cookie jquery file -->
    <script src="vendor/cookie/jquery.cookie.js"></script>

    <!-- sparklines chart jquery file -->
    <script src="vendor/sparklines/jquery.sparkline.min.js"></script>

    <!-- Circular progress gauge jquery file -->
    <script src="vendor/circle-progress/circle-progress.min.js"></script>

    <!-- Swiper carousel jquery file -->
    <script src="vendor/swiper/js/swiper.min.js"></script>

    <!-- Chart js jquery file -->
    <script src="vendor/chartjs/Chart.bundle.min.js"></script>
    <script src="vendor/chartjs/utils.js"></script>

    <!-- Footable jquery file -->
    <script src="vendor/footable-bootstrap/js/footable.min.js"></script>

    <!-- datepicker jquery file -->
    <script src="vendor/bootstrap-daterangepicker-master/moment.js"></script>
    <script src="vendor/bootstrap-daterangepicker-master/daterangepicker.js"></script>

    <!-- jVector map jquery file -->
    <script src="vendor/jquery-jvectormap/jquery-jvectormap.js"></script>
    <script src="vendor/jquery-jvectormap/jquery-jvectormap-world-mill-en.js"></script>

    <!-- circular progress file -->
    <script src="vendor/circle-progress/circle-progress.min.js"></script>

    <!-- Application main common jquery file -->
    <script src="js/main.js"></script>

	<!-- page specific script -->
	<script>
$(document).ready(function(){
	$('#edit_profile_form').on('submit', function(event){
		event.preventDefault();
		if($('#user_new_password').val() != '')
		{
			if($('#user_new_password').val() != $('#user_re_enter_password').val())
			{
				$('#error_password').html('<label class="text-danger">Password Not Match</label>');
				return false;
			}
			else
			{
				$('#error_password').html('');
			}
		}
		$('#edit_prfile').attr('disabled', 'disabled');
		var form_data = $(this).serialize();
		$('#user_re_enter_password').attr('required',false);
		$.ajax({
			url:"edit_profile.php",
			method:"POST",
			data:form_data,
			success:function(data)
			{
				$('#edit_prfile').attr('disabled', false);
				$('#user_new_password').val('');
				$('#user_re_enter_password').val('');
				$('#message').html(data);
			}
		})
	});
});
</script>

</body>
</html>
