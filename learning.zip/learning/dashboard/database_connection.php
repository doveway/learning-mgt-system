<?php
//database_connection.php

$connect = new PDO('mysql:host=localhost;dbname=myinstantshipper_newFixdb', 'myinstantshipper_newFix49q', 'xX34rTy9@U');
session_start();
?>