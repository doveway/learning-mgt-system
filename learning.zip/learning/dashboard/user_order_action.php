<?php

//user_action.php

include('database_connection.php');

if(isset($_POST['btn_action']))
{
	// if($_POST['btn_action'] == 'Add')
	// {
	// 	$query = "
	// 	INSERT INTO user_details (user_email, user_password, user_name, user_phone, user_sex, user_type, user_status) 
	// 	VALUES (:user_email, :user_password, :user_name, :user_phone, :user_sex, :user_type, :user_status)
	// 	";	
	// 	$statement = $connect->prepare($query);
	// 	$statement->execute(
	// 		array(
	// 			':user_email'		=>	$_POST["user_email"],
	// 			':user_password'	=>	password_hash($_POST["user_password"], PASSWORD_DEFAULT),
    //             ':user_name'		=>	$_POST["user_name"],
    //             ':user_phone'		=>	$_POST["user_phone"],
    //             ':user_sex'		=>	$_POST["user_sex"],
	// 			':user_type'		=>	'user',
	// 			':user_status'		=>	'active'
	// 		)
	// 	);
	// 	$result = $statement->fetchAll();
	// 	if(isset($result))
	// 	{
	// 		echo 'New User Added';
	// 	}
	// }
	if($_POST['btn_action'] == 'fetch_single')
	{
		$query = "
		SELECT * FROM user_orders WHERE user_order_id = :user_order_id
		";
		$statement = $connect->prepare($query);
		$statement->execute(
			array(
				':user_order_id'	=>	$_POST["user_order_id"]
			)
		);
		$result = $statement->fetchAll();
		$output = array();
		foreach($result as $row)
		{
			$output['user_inputPounds'] = $row['user_inputPounds'];
            $output['user_est_price'] = $row['user_est_price'];
            $output['user_order_description'] = $row['user_order_description'];
		}
		echo json_encode($output);
	}
	if($_POST['btn_action'] == 'Edit')
	{
			$query = "
			UPDATE user_orders SET 
                user_inputPounds = '".$_POST["user_inputPounds"]."', 
                user_est_price = '".$_POST["user_est_price"]."',
                user_order_description = '".$_POST["user_order_description"]."'
				WHERE user_order_id = '".$_POST["user_order_id"]."'
			";
		$statement = $connect->prepare($query);
		$statement->execute();
		$result = $statement->fetchAll();
		if(isset($result))
		{
			echo 'User Details Edited';
		}
	}
	if($_POST['btn_action'] == 'delete')
	{
		$sql = "DELETE FROM user_orders WHERE user_order_id = '24' ";//user_order_id not working yet

		// use exec() because no results are returned
		$connect->exec($sql);
		echo "Record deleted successfully";

		// $result = $statement->fetchAll();	
		// if(isset($result))
		// {
		// 	echo 'User Status change to ' . $status;
		// }
	}
}

?>