<?php
//error_reporting(0);
include('../database_connection.php');
if(!isset($_SESSION['type']))
{
	header('location:../auth/login.php');
}

?>
<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no, viewport-fit=cover">

    <!-- favicons -->
    <!-- <link rel="apple-touch-icon" href="img/favicon-apple.png">
    <link rel="icon" href="img/favicon.png"> -->




    <!-- Material design icons CSS -->
    <link rel="stylesheet" href="vendor/materializeicon/material-icons.css">

    <!-- aniamte CSS -->
    <link rel="stylesheet" href="vendor/animatecss/animate.css">

    <!-- swiper carousel CSS -->
    <link rel="stylesheet" href="vendor/swiper/css/swiper.min.css">

    <!-- daterange CSS -->
    <link rel="stylesheet" href="vendor/bootstrap-daterangepicker-master/daterangepicker.css">

    <!-- footable CSS -->
    <link rel="stylesheet" href="vendor/footable-bootstrap/css/footable.bootstrap.min.css">

    <!-- jvector map CSS -->
    <link rel="stylesheet" href="vendor/jquery-jvectormap/jquery-jvectormap-2.0.3.css">

    <!-- app CSS -->
    <link id="theme" rel="stylesheet" href="css/purplesidebar.css" type="text/css">

    <title>Create Course</title>
</head>

<body class="fixed-header sidebar-right-close">
    
    <div class="wrapper">
        <!-- main header -->
        <?php include('header.php'); ?>
        <!-- main header ends -->
        <!-- sidebar left -->
        <?php include('left-navbar.php'); ?>
        <!-- sidebar left ends -->
        

        <!-- content page title -->
        <div class="container-fluid bg-light-opac">
            <div class="row">
                <div class="container my-3 main-container">
                    <div class="row align-items-center">
                        <div class="col">
                            <h2 class="content-color-primary page-title">Create Course</h2>
                            <p class="content-color-secondary page-sub-title"></p>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
        <!-- content page title ends -->

        <!-- content page -->
        <div class="container mt-4 main-container">
			<div class="card mb-4">
				<div class="card-header border-bottom">
					<div class="media">
						<div class="icon-circle icon-40 bg-light-primary mr-3">
							<i class="material-icons">business</i>
						</div>
						<div class="media-body">
							<h6 class="my-0 content-color-primary">Add a Course</h6>
							<p class="small mb-0">All added courses automatically updates on the website</p>
						</div>
					</div>
				</div>
                <div class="card-body">
                    <div class="row justify-content-center">
                        <div class="col-md-10 ">
                        	<form id="form" method="post" enctype="multipart/form-data">                       	
                            
                            <span id="message"></span>
					       	<div class="form-group row">
                                <div class="col-lg-6 col-md-6">
                                    <label>Course Title</label>
                                    <input type="text" name="course_title" id="course_title" placeholder="Course Title" class="form-control" required>
    
                                </div>
                                <div class="col-lg-6 col-md-6">
                                    <label>Course Price</label>
                                    <input type="number" name="course_price" id="course_price" placeholder="Course Price" class="form-control" required>
    
                                </div>
                                
                                
                            </div>
                                
                                <br>
                                
                            <div class="form-group row">
                                <div class="col-lg-6 col-md-6">
                                    <label>No of Lectures</label>
                                    <input type="number" name="no_of_lectures" id="no_of_lectures" placeholder="No of Lectures" class="form-control" required>
    
                                </div>
                                <div class="col-lg-6 col-md-6">
                                    <label>No of Test</label>
                                    <input type="text" name="course_test" id="course_test" placeholder="No of Test" class="form-control" required>
    
                                </div>
                                
                                
                            </div>
                                
                                <br>
                                
                            <div class="form-group row">
                                <div class="col-lg-6 col-md-6">
                                    <label>Course Category</label>
                                    <select class="custom-select" id="course_category" name="course_category">
                                            <option value="Programming">Programming</option>
                                            <option value="English Speaking">English Speaking</option>
                                        </select>
    
                                </div>
                                <div class="col-lg-6 col-md-6">
                                    <label>Course Level</label>
                                    <select class="custom-select" id="course_level" name="course_level">
                                            <option value="Beginner">Beginner</option>
                                            <option value="Intermediate">Intermediate</option>
                                        </select>
    
                                </div>
                                
                                
                            </div>
                                                                      
                            <br>
                                
                            <div class="form-group row">
                                <div class="col-lg-6 col-md-6">
                                    <label>Course Language</label>
                                    <select class="custom-select" id="course_language" name="course_language">
                                            <option value="English">English</option>
                                            <option value="French">French</option>
                                        </select>
    
                                </div>
                                <div class="col-lg-6 col-md-6">
                                    <label>Course Tutor</label>
                                    <select class="custom-select" id="course_tutor" name="course_tutor">
                                            <option value="Doveway">Doveway</option>
                                            <option value="Oluchi">Oluchi</option>
                                        </select>
    
                                </div>
                                
                                
                            </div>
                                                                      
                            <br>
                                
                            <div class="form-group row">
                                <div class="col-lg-6 col-md-6">
                                    <label>Course Duration</label>
                                    <input type="text" name="course_duration" id="course_duration" placeholder="Course Duration" class="form-control" required>
    
                                </div>
                                
                            </div>
                                                                      
                            <br>
                                
                        

                            <div class="form-group row">
                                <div class="col-lg-12 col-md-12">
                                    <label>Course Overview</label>
                                    <textarea name="course_overview" id="course_overview" placeholder="Course Overview" class="form-control" rows="4" required></textarea>
                                </div>
                            </div>
                            <br>
                            
                             <div class="form-group row">
                                <div class="col-lg-12 col-md-12">
                                    <label>Upload Image 1</label>
                                    <input id="uploadImage" type="file" accept="image/*" name="image" />
                                </div>
                            </div>
                            <br>
                                
                           
  
                            <div class="card-footer">
                                <button type="reset" class="btn btn-secondary">Cancel</button>
                                <input type="submit" value=" Add Course " name="submit" id="submit"  class="btn btn-primary pink-gradient" />
                            </div>
                            </form>
                        




                        </div>
                    </div>
				</div>
			</div>
		</div>
        <!-- content page ends -->

    </div>
	<?php include('footer.php'); ?>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="vendor/bootstrap-4.1.3/js/bootstrap.min.js"></script>

    <!-- Cookie jquery file -->
    <script src="vendor/cookie/jquery.cookie.js"></script>

    <!-- sparklines chart jquery file -->
    <script src="vendor/sparklines/jquery.sparkline.min.js"></script>

    <!-- Circular progress gauge jquery file -->
    <script src="vendor/circle-progress/circle-progress.min.js"></script>

    <!-- Swiper carousel jquery file -->
    <script src="vendor/swiper/js/swiper.min.js"></script>

    <!-- Chart js jquery file -->
    <script src="vendor/chartjs/Chart.bundle.min.js"></script>
    <script src="vendor/chartjs/utils.js"></script>

    <!-- Footable jquery file -->
    <script src="vendor/footable-bootstrap/js/footable.min.js"></script>

    <!-- datepicker jquery file -->
    <script src="vendor/bootstrap-daterangepicker-master/moment.js"></script>
    <script src="vendor/bootstrap-daterangepicker-master/daterangepicker.js"></script>

    <!-- jVector map jquery file -->
    <script src="vendor/jquery-jvectormap/jquery-jvectormap.js"></script>
    <script src="vendor/jquery-jvectormap/jquery-jvectormap-world-mill-en.js"></script>

    <!-- circular progress file -->
    <script src="vendor/circle-progress/circle-progress.min.js"></script>

    <!-- Application main common jquery file -->
    <script src="js/main.js"></script>

	<!-- page specific script -->
	<script>
    $(document).ready(function (e) {
 $("#form").on('submit',(function(e) {
  e.preventDefault();
  $.ajax({
         url: "create_course_process.php",
   type: "POST",
   data:  new FormData(this),
   contentType: false,
         cache: false,
   processData:false,
   beforeSend : function()
   {
    //$("#preview").fadeOut();
    $("#err").fadeOut();
   },
   success: function(data)
      {
    if(data=='invalid')
    {
     // invalid file format.
     $("#err").html("Invalid File !").fadeIn();
    }
    else
    {
     // view uploaded file.
     $("#message").html(data).fadeIn();
     $("#form")[0].reset(); 
    }
      },
     error: function(e) 
      {
    $("#err").html(e).fadeIn();
      }          
    });
 }));
});
</script>
</body>
</html>
