<?php
//login.php
error_reporting(0);
include('database_connection.php');

if(isset($_SESSION['type']))
{
	header("location:profile.php");
}

if(isset($_POST["submit"])){
    $user_password = password_hash($_POST["user_password"], PASSWORD_DEFAULT);
    $user_email = $_POST['user_email'];
    $message ='';
    
    try {
    
    $connect->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); // <== add this line

    $query1 = "SELECT * FROM user_details WHERE user_email = '$user_email' ";
 
    $stmt = $connect->prepare($query1);
    $stmt->execute();
    $num = $stmt->rowCount();
    if($num<1){
        $sql = "INSERT INTO user_details (user_email, user_password,user_name,user_phone,user_sex,user_address,user_type,user_status,user_bank,user_account_name)
        VALUES ('".$_POST["user_email"]."','".$user_password."','".$_POST["user_name"]."','Enter Phone Number','','Enter your address','user','active','','')";
        if ($connect->query($sql)) {
            $message2 = 'Account successfully created, please login';
        }
        else{
        echo "<script type= 'text/javascript'>alert('Account NOT created. Please try again');</script>";
        }
    
    }else
    {
        $message = 'Email already exist, please use a different email';
    }
    
    $connect = null;
    }
    catch(PDOException $e)
    {
    echo $e->getMessage();
    }
    
    }

// $query = "
// 		INSERT INTO user_details (user_email, user_password, user_name, user_type, user_status) 
// 		VALUES (:user_email, :user_password, :user_name, :user_type, :user_status)
// 		";	
// 		$statement = $connect->prepare($query);
// 		$statement->execute(
// 			array(
// 				':user_email'		=>	$_POST["user_email"],
// 				':user_password'	=>	password_hash($_POST["user_password"], PASSWORD_DEFAULT),
// 				':user_name'		=>	$_POST["user_name"],
// 				':user_type'		=>	'user',
// 				':user_status'		=>	'active'
// 			)
// 		);
?>
<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no, viewport-fit=cover">

    <!-- favicons -->
    <!-- <link rel="apple-touch-icon" href="img/favicon-apple.png">
    <link rel="icon" href="img/favicon.png"> -->




    <!-- Material design icons CSS -->
    <link rel="stylesheet" href="vendor/materializeicon/material-icons.css">

    <!-- aniamte CSS -->
    <link rel="stylesheet" href="vendor/animatecss/animate.css">

    <!-- swiper slider CSS -->
    <link rel="stylesheet" href="vendor/swiper/css/swiper.min.css">

    <!-- app CSS -->
    <link id="theme" rel="stylesheet" href="css/purplesidebar.css" type="text/css">

    <title>MyInstantshippers::Login</title>
</head>

<body class="fixed-header sidebar-right-close sidebar-left-close">
    

    <div class="wrapper h-100  h-sm-auto justify-content-center">
        <!-- main header -->
        <header class="main-header">
            <div class="container-fluid">
                <div class="row align-items-center">
                    <div class="col-auto pl-0">
                    <a href="../index.php" class="btn pink-gradient rounded d-inline-block" ><i class="material-icons">home</i> Home</a>
                        <a href="index.php" class="logo"><!--<img src="img/logo-icon.png" alt="">--></a>
                    </div>
                    <div class="col text-center p-xs-0">
                        <ul class="time-day">
                            <li class="text-right">
                                <p class="header-color-primary"><span class="header-color-secondary"></span><small></small></p>
                                <h2></h2>
                            </li>
                            <li class="text-left">
                                <h2><span class="header-color-secondary font-weight-light"><sup></sup></span></h2>
                                <p class="header-color-primary text-hide-lg"><span class="header-color-secondary"></span><small></small></p>
                            </li>
                        </ul>

                    </div>
                    <div class="col-auto">
                        
                        <a href="login.php" class="btn pink-gradient rounded d-inline-block" ><i class="material-icons">person</i> Sign In</a>
                    </div>
                </div>
            </div>
        </header>
        <!-- main header ends -->

        

        <!-- content page -->
        <div class="carosel swiper-location-carousel bg-dark background-img position-fixed">
            <div data-pagination='{"el": ".swiper-pagination"}' data-space-between="0" data-slides-per-view="1" class="swiper-container swiper-init swiper-signin h-100">
                <div class="swiper-pagination"></div>
                <div class="swiper-wrapper">
                    <div class="swiper-slide text-center ">
                        <div class="background-img"><img src="img/banner.png" alt="" class="w-100"></div>
                    </div>
                    <div class="swiper-slide text-center">
                        <div class="background-img"><img src="img/banner2.png" alt="" class="w-100"></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container h-100  h-sm-auto align-items-center">
            <div class="row align-items-center h-100  h-sm-auto">
                <div class="col-12 col-sm-8 col-md-6 col-lg-5 col-xl-4 mx-auto text-center">
                    
					<form method="post" action="" id="user_form">
						<h4 class="font-weight-light mb-5 text-white text-center">Create an account to start shipping your goods.</h4>
						<span style="color:red"><?php  echo $message; ?></span>
						<span style="color:green"><?php  echo $message2; ?></span>
						<div class="card mb-3">
							
                            <div class="card-body p-0">
                                <label for="name" class="sr-only">Your Full Name</label>
                                <input type="text" id="user_name" name="user_name" class="form-control text-center form-control-lg border-0" placeholder="Your Name" required="" autofocus="">
                                <hr class="my-0"> 
                                <label for="inputEmail" class="sr-only">Email address</label>
                                <input type="email" id="user_email" name="user_email" class="form-control text-center form-control-lg border-0" placeholder="Email address" required="" >
                                <hr class="my-0">
                                <!-- <label for="inputPhone" class="sr-only">Phone No.</label>
                                <input type="text" id="user_phone" name="user_phone" class="form-control text-center form-control-lg border-0" placeholder="Phone No." required="">
                                <label for="inputPassword" class="sr-only">Password</label> -->
                                <input type="password" id="user_password" name="user_password" class="form-control text-center form-control-lg border-0" placeholder="Password" required="">
                                <hr class="my-0">
                                
                            </div>
                            
						</div>
						
						<div class="text-center">
                        
        				<input type="submit" value=" Create Account " name="submit"  class="btn btn-primary pink-gradient"/>
						</div>
						<br>
						
					</form>

                </div>
            </div>
        </div>
        <!-- content page ends -->

    </div>
    <footer class="border-top">
        <div class="row">
            <div class="col-12 col-sm-6 text-white">Powered by DovewayCreations</div>
            <div class="col-12 col-sm-6 text-right text-white"><a href="#" class="text-white">Privacy Policy</a> | <a href="#" class="text-white">Terms of use</a></div>
        </div>
    </footer>




    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="vendor/bootstrap-4.1.3/js/bootstrap.min.js"></script>

    <!-- Cookie jquery file -->
    <script src="vendor/cookie/jquery.cookie.js"></script>

    <!-- swiper slider jquery file -->
    <script src="vendor/swiper/js/swiper.min.js"></script>

    <!-- Application main common jquery file -->
    <script src="js/main.js"></script>

    <!-- page specific script -->
    <script>
        'use strict';
        var mySwiper = new Swiper('.swiper-signin', {
            slidesPerView: 1,
            spaceBetween: 0,
            autoplay: true,
            pagination: {
                el: '.swiper-pagination',
                clickable: true,
            }
        });

    </script>
</body>
</html>
