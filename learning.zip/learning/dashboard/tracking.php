<?php
//error_reporting(0);
include('database_connection.php');
if(!isset($_SESSION['type']))
{
	header('location:login.php');
}
?>
<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no, viewport-fit=cover">


    <!-- Material design icons CSS -->
    <link rel="stylesheet" href="vendor/materializeicon/material-icons.css">

    <!-- aniamte CSS -->
    <link rel="stylesheet" href="vendor/animatecss/animate.css">

    <!-- swiper carousel CSS -->
    <link rel="stylesheet" href="vendor/swiper/css/swiper.min.css">

    <!-- daterange CSS -->
    <link rel="stylesheet" href="vendor/bootstrap-daterangepicker-master/daterangepicker.css">

    <!-- footable CSS -->
    <link rel="stylesheet" href="vendor/footable-bootstrap/css/footable.bootstrap.min.css">

    <!-- jvector map CSS -->
    <link rel="stylesheet" href="vendor/jquery-jvectormap/jquery-jvectormap-2.0.3.css">

    <!-- app CSS -->
    <link id="theme" rel="stylesheet" href="css/purplesidebar.css" type="text/css">

    <title>MyInstantshippers::Tracking</title>
</head>

<body class="fixed-header sidebar-right-close">
    

    <div class="wrapper">
        <!-- main header -->
        <?php include('header.php'); ?>
        <!-- main header ends -->

        <!-- sidebar left -->
        <?php include('left-navbar.php'); ?>
        <!-- sidebar left ends -->

        <!-- content page title -->
        <div class="container-fluid bg-light-opac">
            <div class="row">
                <div class="container my-3 main-container">
                    <div class="row align-items-center">
                        <div class="col">
                            <h2 class="content-color-primary page-title">Tracking</h2>
                            <p class="content-color-secondary page-sub-title">Monitor the progress of your package delivery</p>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
        <!-- content page title ends -->

        <?php
                // get passed parameter value, in this case, the record ID
                // isset() is a PHP function used to verify if a value is there or not
                $user_order_id=isset($_GET['user_order_id']) ? $_GET['user_order_id'] : die('ERROR: Order ID not found.');
                
                // read current record's data
                try {
                    // prepare select query
                    $query = "SELECT * FROM user_orders WHERE user_order_id = ? LIMIT 0,1";
                    $stmt = $connect->prepare( $query );
                    
                    // this is the first question mark
                    $stmt->bindParam(1, $user_order_id);
                    
                    // execute our query
                    $stmt->execute();
                    
                    // store retrieved row to a variable
                    $row = $stmt->fetch(PDO::FETCH_ASSOC);
                    
                    // values to fill up our form
                    $user_inputPounds = $row['user_inputPounds'];
                    $user_est_price = $row['user_est_price'];
                    $user_order_description = $row['user_order_description'];
                    $user_order_actual_fee = $row['user_order_actual_fee'];
                    $user_shipping_info1 = $row['user_shipping_info1'];
                    $user_shipping_info1_date = date("d-m-Y",strtotime($row['user_shipping_info1_date']));
                    $user_shipping_info2 = $row['user_shipping_info2'];
                    $user_shipping_info2_date = date("d-m-Y",strtotime($row['user_shipping_info2_date']));
                    $user_shipping_info3 = $row['user_shipping_info3'];
                    $user_shipping_info3_date = date("d-m-Y",strtotime($row['user_shipping_info3_date']));
                    $user_shipping_info4 = $row['user_shipping_info4'];
                    $user_shipping_info4_date = date("d-m-Y",strtotime($row['user_shipping_info4_date']));
                    $order_date_created = date("d-m-Y",strtotime($row['order_date_created']));
                    
                }
                
                // show error
                catch(PDOException $exception){
                    die('ERROR: ' . $exception->getMessage());
                }

                
                ?>
        <!-- content page -->
        <div class="container mt-4 main-container">
            
            <div class="row">
                <div class="col-12 col-md-6 col-lg-4">
                    <div class="card mb-4">
                        <div class="card-body">
                        <?php
                            if($user_shipping_info1 =='' AND $user_shipping_info2 =='' AND $user_shipping_info3 =='' AND $user_shipping_info4 =='')
                            {
                                echo '<p>No shipping information yet. <br> Please check again soon.</p>';
                            }
                            if($user_shipping_info1 !=='' AND $user_shipping_info2 =='' AND $user_shipping_info3 =='' AND $user_shipping_info4 =='')
                            {
                                echo '  <ul class="list-group list-group-flush w-100 log-information mt-3">
                                            <li class="list-group-item">
                                                <div class="avatar avatar-15 border-danger"></div>
                                                <p class="content-color-primary">'.$user_shipping_info1.'
                                                <br><small class="content-color-secondary">'.$user_shipping_info1_date.'</small></p>
                                            </li>
                                        </ul>';
                            }
                            if($user_shipping_info1 !=='' AND $user_shipping_info2 !=='' AND $user_shipping_info3 =='' AND $user_shipping_info4 =='')
                            {
                                echo '  <ul class="list-group list-group-flush w-100 log-information mt-3">
                                            <li class="list-group-item">
                                                <div class="avatar avatar-15 border-danger"></div>
                                                <p class="content-color-primary">'.$user_shipping_info1.'
                                                <br><small class="content-color-secondary">'.$user_shipping_info1_date.'</small></p>
                                            </li>
                                            <li class="list-group-item">
                                                <div class="avatar avatar-15 border-warning"></div>
                                                <p class="content-color-primary">'.$user_shipping_info2.'
                                                <br><small class="content-color-secondary">'.$user_shipping_info2_date.'</small></p>
                                            </li>
                                        </ul>';
                            }
                            if($user_shipping_info1 !=='' AND $user_shipping_info2 !=='' AND $user_shipping_info3 !=='' AND $user_shipping_info4 =='')
                            {
                                echo '  <ul class="list-group list-group-flush w-100 log-information mt-3">
                                            <li class="list-group-item">
                                                <div class="avatar avatar-15 border-danger"></div>
                                                <p class="content-color-primary">'.$user_shipping_info1.'
                                                <br><small class="content-color-secondary">'.$user_shipping_info1_date.'</small></p>
                                            </li>
                                            <li class="list-group-item">
                                                <div class="avatar avatar-15 border-warning"></div>
                                                <p class="content-color-primary">'.$user_shipping_info2.'
                                                <br><small class="content-color-secondary">'.$user_shipping_info2_date.'</small></p>
                                            </li>
                                            <li class="list-group-item">
                                                <div class="avatar avatar-15 border-primary"></div>
                                                <p class="content-color-primary">'.$user_shipping_info3.'
                                                <br><small class="content-color-secondary">'.$user_shipping_info3_date.'</small></p>
                                            </li>
                                        </ul>';
                            }
                            if($user_shipping_info1 !=='' AND $user_shipping_info2 !=='' AND $user_shipping_info3 !=='' AND $user_shipping_info4 !=='' )
                            {
                                echo '  <ul class="list-group list-group-flush w-100 log-information mt-3">
                                            <li class="list-group-item">
                                                <div class="avatar avatar-15 border-danger"></div>
                                                <p class="content-color-primary">'.$user_shipping_info1.'
                                                <br><small class="content-color-secondary">'.$user_shipping_info1_date.'</small></p>
                                            </li>
                                            <li class="list-group-item">
                                                <div class="avatar avatar-15 border-warning"></div>
                                                <p class="content-color-primary">'.$user_shipping_info2.'
                                                <br><small class="content-color-secondary">'.$user_shipping_info2_date.'</small></p>
                                            </li>
                                            <li class="list-group-item">
                                                <div class="avatar avatar-15 border-primary"></div>
                                                <p class="content-color-primary">'.$user_shipping_info3.'
                                                <br><small class="content-color-secondary">'.$user_shipping_info3_date.'</small></p>
                                            </li>
                                            <li class="list-group-item">
                                                <div class="avatar avatar-15 border-success"></div>
                                                <p class="content-color-primary">'.$user_shipping_info4.'
                                                <br><small class="content-color-secondary">'.$user_shipping_info4_date.'</small></p>
                                            </li>
                                        </ul>';
                            }
                        ?>

                        </div>
                    </div>

                </div>

                <div class="col-12 col-md-6 col-lg-4">
                    <div class="card mb-4">
                        <div class="blog-header-img">
                            <img class="" src="img/team.jpg" alt="">
                        </div>
                        <div class="card-body">
                        <ul class="list-group list-group-flush w-100 log-information mt-3">
                                <li class="list-group-item">
                                    <div class="avatar avatar-15 border-success"></div>
                                    <p class="content-color-primary"><strong>Order ID:</strong> <?php echo $user_order_id; ?>
                                        
                                </li>
                                <li class="list-group-item">
                                    <span class="avatar avatar-15 border-success"></span>
                                    <p class="content-color-primary"><strong>Order Date:</strong> <?php echo $order_date_created; ?>
                                        
                                </li>
                                <li class="list-group-item">
                                    <span class="avatar avatar-15 border-success"></span>
                                    <p class="content-color-primary"><strong>Weight (lbs):</strong> <?php echo $user_inputPounds; ?> lbs
                                        
                                </li>
                                <li class="list-group-item">
                                    <span class="avatar avatar-15 border-success"></span>
                                    <p class="content-color-primary"><strong>Package Description:</strong> <?php echo $user_order_description; ?>
                                        
                                </li>
                                
                            </ul>
                        </div>
                        
                    </div>
                </div>
                
            </div>

        </div>
        <!-- content page ends -->

    </div>
    <?php include('footer.php'); ?>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="vendor/bootstrap-4.1.3/js/bootstrap.min.js"></script>

    <!-- Cookie jquery file -->
    <script src="vendor/cookie/jquery.cookie.js"></script>

    <!-- sparklines chart jquery file -->
    <script src="vendor/sparklines/jquery.sparkline.min.js"></script>

    <!-- Circular progress gauge jquery file -->
    <script src="vendor/circle-progress/circle-progress.min.js"></script>

    <!-- Swiper carousel jquery file -->
    <script src="vendor/swiper/js/swiper.min.js"></script>

    <!-- Chart js jquery file -->
    <script src="vendor/chartjs/Chart.bundle.min.js"></script>
    <script src="vendor/chartjs/utils.js"></script>

    <!-- Footable jquery file -->
    <script src="vendor/footable-bootstrap/js/footable.min.js"></script>

    <!-- datepicker jquery file -->
    <script src="vendor/bootstrap-daterangepicker-master/moment.js"></script>
    <script src="vendor/bootstrap-daterangepicker-master/daterangepicker.js"></script>

    <!-- jVector map jquery file -->
    <script src="vendor/jquery-jvectormap/jquery-jvectormap.js"></script>
    <script src="vendor/jquery-jvectormap/jquery-jvectormap-world-mill-en.js"></script>

    <!-- circular progress file -->
    <script src="vendor/circle-progress/circle-progress.min.js"></script>

    <!-- Application main common jquery file -->
    <script src="js/main.js"></script>

    <!-- page specific script -->
</body>


</html>
