<?php
include('database_connection.php');
if(!isset($_SESSION['type']))
{
	header('location:login.php');
}
$user_id = $_SESSION["user_id"];

//new format
// PAGINATION VARIABLES
// page is the current page, if there's nothing set, default is page 1
$page = isset($_GET['page']) ? $_GET['page'] : 1;
 
// set records or rows of data per page
$records_per_page = 15;
 
// calculate for the query LIMIT clause
$from_record_num = ($records_per_page * $page) - $records_per_page;
 
// delete message prompt will be here
$action = isset($_GET['action']) ? $_GET['action'] : "";



// select data for current page
$query = "SELECT * FROM user_orders ORDER BY user_order_id DESC
    LIMIT :from_record_num, :records_per_page";
 
$stmt = $connect->prepare($query);
$stmt->bindParam(":from_record_num", $from_record_num, PDO::PARAM_INT);
$stmt->bindParam(":records_per_page", $records_per_page, PDO::PARAM_INT);
$stmt->execute();
 


?>
    <!doctype html>
    <html lang="en">

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no, viewport-fit=cover">

        <!-- favicons -->
        <!-- <link rel="apple-touch-icon" href="img/favicon-apple.png">
    <link rel="icon" href="img/favicon.png"> -->

        <!-- Material design icons CSS -->
        <link rel="stylesheet" href="vendor/materializeicon/material-icons.css">

        <!-- aniamte CSS -->
        <link rel="stylesheet" href="vendor/animatecss/animate.css">

        <!-- swiper carousel CSS -->
        <link rel="stylesheet" href="vendor/swiper/css/swiper.min.css">

        <!-- daterange CSS -->
        <link rel="stylesheet" href="vendor/bootstrap-daterangepicker-master/daterangepicker.css">

        <!-- dataTable CSS -->
        <link rel="stylesheet" href="vendor/DataTables-1.10.18/css/dataTables.bootstrap4.min.css">

        <!-- jvector map CSS -->
        <link rel="stylesheet" href="vendor/jquery-jvectormap/jquery-jvectormap-2.0.3.css">

        <!-- app CSS -->
        <link id="theme" rel="stylesheet" href="css/purplesidebar.css" type="text/css">

        <title>MyInstantshippers::User Orders</title>
    </head>

    <body class="fixed-header sidebar-right-close">

        <div class="wrapper">
            <!-- main header -->
            <?php include('header.php'); ?>
                <!-- main header ends -->

                <!-- sidebar left -->
                <?php include('left-navbar.php'); ?>
                    <!-- sidebar left ends -->

                    <!-- content page title -->
                    <div class="container-fluid bg-light-opac">
                        <div class="row">
                            <div class="container my-3 main-container">
                                <div class="row align-items-center">
                                    <div class="col">
                                        <h2 class="content-color-primary page-title">My Orders</h2>
                                        <p class="content-color-secondary page-sub-title">View, Update or delete your order</p>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- content page title ends -->

                    <!-- content page -->
                    <div class="container mt-4 main-container">
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="card mb-4 fullscreen">
                                    <div class="card-header">
                                        <div class="media">
                                            <div class="media-body">
                                                <h4 class="content-color-primary mb-0">Order List</h4>
                                            </div>
                                            
                                            <a href="javascript:void(0);" class="icon-circle icon-30 content-color-secondary fullscreenbtn">
                                                <i class="material-icons ">crop_free</i>
                                            </a>
                                        </div>
                                        
                                    </div>
                                    <?php
                                                // if it was redirected from delete.php
                                                if($action=='deleted'){
                                                    echo "<div class='alert alert-success'>Order was deleted.</div>";
                                                }
                                            ?>
                                    <div class="card-body">
                                        <?php 
                                        // this is how to get number of rows returned
                                            $num = $stmt->rowCount();
                                            
                                          
                                            
                                            //check if more than 0 record found
                                            if($num>0){
                                            
                                                // data from database will be here
                                                echo "<table class='table'>";//start table
                                            
                                                //creating our table heading
                                                echo "<tr>";
                                                    echo "<th>Order ID</th>";
                                                    echo "<th>Weight(Pounds)</th>";
                                                    echo "<th>Estimated Fee</th>";
                                                    echo "<th>Actual Fee</th>";
                                                    echo "<th>Invoice</th>";
                                                    echo "<th>Waybill</th>";
                                                    echo "<th>Edit</th>";
                                                    echo "<th>Delete</th>";
                                                echo "</tr>";
                                                
                                                // table body will be here
                                                // retrieve our table contents
                                            // fetch() is faster than fetchAll()
                                            // http://stackoverflow.com/questions/2770630/pdofetchall-vs-pdofetch-in-a-loop
                                            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
                                                // extract row
                                                // this will make $row['firstname'] to
                                                // just $firstname only
                                                extract($row);
                                                
                                                // creating new table row per record
                                                echo "<tr>";
                                                    echo "<td>{$user_order_id}</td>";
                                                    echo "<td>{$user_inputPounds}</td>";
                                                    echo "<td>&#36;{$user_est_price}</td>";
                                                    echo "<td>&#36;{$user_order_actual_fee}</td>";
                                                    echo "<td><a href='view_order.php?pdf=1&user_order_id=".$row['user_order_id']."&user_id=".$row['user_id']."&order_date_created=".$row['order_date_created']."' class='btn btn-info btn-xs' target='_blank'>View PDF</a></td>";
                                                    echo "<td><a href='waybill.php?pdf=1&user_order_id=".$row['user_order_id']."&user_id=".$row['user_id']."&order_date_created=".$row['order_date_created']."' class='btn btn-info btn-xs' target='_blank'>Waybill</a></td>";
                                                    echo "<td><a href='update_order_admin.php?user_order_id={$user_order_id}&user_id={$user_id}' class='btn btn-warning btn-xs'>Edit</a></td>";                                                    
                                                    echo "<td><a href='#' onclick='delete_order({$user_order_id});'  class='btn btn-danger'>Delete</a></td>";
                                                echo "</tr>";
                                            }
                                            
                                            // end table
                                            echo "</table>";
                                            // PAGINATION
                                            // count total number of rows
                                            $query = "SELECT COUNT(*) as total_rows FROM user_orders";
                                            $stmt = $connect->prepare($query);
                                            
                                            // execute query
                                            $stmt->execute();
                                            
                                            // get total rows
                                            $row = $stmt->fetch(PDO::FETCH_ASSOC);
                                            $total_rows = $row['total_rows'];

                                            // paginate records
                                            $page_url="admin_orders.php?";
                                            include_once "paging.php";
                                                
                                            }
                                            
                                            // if no records found
                                            else{
                                                echo "<div class='alert alert-danger'>You have no order yet. Click Create New Order to start shipping your package.</div>";
                                            }

                                        ?>


                                        

                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>

                    <!-- main container ends -->

        </div>
        <?php include('footer.php'); ?>

            <!-- Optional JavaScript -->
            <!-- jQuery first, then Popper.js, then Bootstrap JS -->
            <script src="js/jquery-3.2.1.min.js"></script>
            <script src="js/popper.min.js"></script>
            <script src="vendor/bootstrap-4.1.3/js/bootstrap.min.js"></script>

            <!-- Cookie jquery file -->
            <script src="vendor/cookie/jquery.cookie.js"></script>

            <!-- sparklines chart jquery file -->
            <script src="vendor/sparklines/jquery.sparkline.min.js"></script>

            <!-- Circular progress gauge jquery file -->
            <script src="vendor/circle-progress/circle-progress.min.js"></script>

            <!-- Swiper carousel jquery file -->
            <script src="vendor/swiper/js/swiper.min.js"></script>

            <!-- Chart js jquery file -->
            <script src="vendor/chartjs/Chart.bundle.min.js"></script>
            <script src="vendor/chartjs/utils.js"></script>

            <!-- DataTable jquery file -->
            <script src="vendor/DataTables-1.10.18/js/jquery.dataTables.min.js"></script>
            <script src="vendor/DataTables-1.10.18/js/dataTables.bootstrap4.min.js"></script>

            <!-- datepicker jquery file -->
            <script src="vendor/bootstrap-daterangepicker-master/moment.js"></script>
            <script src="vendor/bootstrap-daterangepicker-master/daterangepicker.js"></script>

            <!-- jVector map jquery file -->
            <script src="vendor/jquery-jvectormap/jquery-jvectormap.js"></script>
            <script src="vendor/jquery-jvectormap/jquery-jvectormap-world-mill-en.js"></script>

            <!-- circular progress file -->
            <script src="vendor/circle-progress/circle-progress.min.js"></script>

            <!-- Application main common jquery file -->
            <script src="js/main.js"></script>

            <!-- page specific script -->
            

<script type='text/javascript'>
// confirm record deletion
function delete_order( user_order_id ){
     
    var answer = confirm('Sure you want to Delete Order?');
    if (answer){
        // if user clicked ok, 
        // pass the id to delete.php and execute the delete query
        window.location = 'delete_admin.php?user_order_id=' + user_order_id;
    } 
}
</script>
    </body>

    </html>