<?php
date_default_timezone_set("Africa/Lagos");
//include_once('../../secure.php');
include('database_connection.php');

$course_id = $_GET['id'];

/////course table display from $_GET['id]
$queryCourse1 = "
SELECT * FROM courses 
WHERE id = '$course_id'
";
$statementCourse1 = $connect->prepare($queryCourse1);
$statementCourse1->execute();
$resultCourse1 = $statementCourse1->fetchAll();
foreach($resultCourse1 as $row)
{
	// $bank = $row2['user_bank'];
    // $account_no = $row2['user_account_no'];
    $course_tutor = $row['course_tutor'];
    $course_title = $row['course_title'];
    $course_price = $row['course_price'];
    $course_category = $row['course_category'];
    $course_overview = $row['course_overview'];
    $course_duration = $row['course_duration'];
    $no_of_lectures = $row['no_of_lectures'];
    $course_test = $row['course_test'];
    $course_level = $row['course_level'];
    $course_language = $row['course_language'];
    $image_link = $row['image_link'];

}
?>
<!doctype html>
<html lang="en">

<head>

    <!--====== Required meta tags ======-->
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!--====== Title ======-->
    <title>Swift Online Learning</title>

    <!--====== Favicon Icon ======-->
    <link rel="shortcut icon" href="assets/images/favicon.png" type="image/png">

    <!--====== Bootstrap css ======-->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">

    <!--====== Animate css ======-->
    <link rel="stylesheet" href="assets/css/animate.css">

    <!--====== Fontawesome css ======-->
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">

    <!--====== Magnific Popup css ======-->
    <link rel="stylesheet" href="assets/css/magnific-popup.css">

    <!--====== Nice Select css ======-->
    <link rel="stylesheet" href="assets/css/nice-select.css">

    <!--====== Slick css ======-->
    <link rel="stylesheet" href="assets/css/slick.css">

    <!--====== Default css ======-->
    <link rel="stylesheet" href="assets/css/default.css">

    <!--====== Style css ======-->
    <link rel="stylesheet" href="assets/css/style.css">

    <!--====== Responsive css ======-->
    <link rel="stylesheet" href="assets/css/responsive.css">


</head>

<body>

    <!--====== PRELOADER PART START ======-->

    <div id="preloader">
        <div class="preloader">
            <span></span>
            <span></span>
        </div>
    </div>

    <!--====== PRELOADER PART ENDS ======-->

    <!--====== Header PART START ======-->

    <?php include_once 'header.php'; ?>
    <!--====== Header PART ENDS ======-->

    <!--====== Courses Details Banner PART START ======-->

    <section class="courses_details_banner bg_cover" style="background-image: url(assets/images/about_bg.jpg)">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-9 col-sm-11">
                    <div class="details_banner_content">
                        <h4 class="title"><?php echo $course_title; ?></h4>

                        <div class="details_media_wrapper d-flex flex-wrap">
                            <div class="details_media d-flex align-items-center mt-30">
                                <div class="media_image">
                                    <img class="author" src="assets/images/author-4.jpg" alt="author">
                                </div>
                                <div class="media_content media-body">
                                    <p>Tutor</p>
                                    <h6 class="title"><?php echo $course_tutor; ?></h6>
                                </div>
                            </div>
                            <div class="details_media d-flex align-items-center mt-30">
                                <div class="media_image">
                                    <img class="bookmark" src="assets/images/bookmark.png" alt="bookmark">
                                </div>
                                <div class="media_content media-body">
                                    <p>Category</p>
                                    <h6 class="title"><a href="#"><?php echo $course_category; ?></a></h6>
                                </div>
                            </div>
                          
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!--====== Courses Details Banner PART ENDS ======-->

    <!--====== Courses Details PART START ======-->

    <section class="courses_details_area pt-80 pb-130">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 order-lg-last">
                    <div class="courses_details_sidebar">
                        <div class="courses_sidebar_image">
                            <img src="dashboard/uploads/<?php echo $image_link; ?>" alt="<?php echo $course_title; ?>">
                            <div class="price">
                                <div class="price_wrapper">
                                    <p>Price</p>
                                    <span style="padding-left:10px;padding-right:10px;"><?php echo '&#x20A6;'.number_format($course_price,2); ?></span>
                                </div>
                            </div>
                            <div class="courses_btn">
                                <a class="main-btn" href="#">Buy Now</a>
                            </div>
                        </div>
                        <div class="courses_sidebar_title">
                            <h4 class="title">Course Details</h4>
                        </div>
                        <div class="courses_sidebar_list">
                            <ul class="list">
                                <li><i class="fa fa-clock-o"></i> Duration <span><?php echo $course_duration; ?></span></li>
                                <li><i class="fa fa-files-o"></i> Lectures<span><?php echo $no_of_lectures; ?></span></li>
                                <li><i class="fa fa-puzzle-piece"></i> Test<span><?php echo $course_test; ?></span></li>
                                <li><i class="fa fa-list"></i> Level<span><?php echo $course_level; ?></span></li>
                                <li><i class="fa fa-globe"></i> Language<span><?php echo $course_language; ?></span></li>
                            </ul>
                            <ul class="social">
                                <li><a href="#"><i class="fa fa-facebook-f"></i></a></li>
                                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                                <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-8 order-lg-first">
                    <div class="courses_details_content">
                        <div class="single_courses_details  mt-40">
                            <h4 class="courses_details_title">Overview</h4>
                            <p><?php echo $course_overview; ?></p>
                        </div>
                        
                        <div class="courses_curriculum mt-50">
                            <div class="courses_top_bar d-sm-flex justify-content-between align-items-center">
                                <div class="courses_title">
                                    <h4 class="courses_details_title">Overview</h4>
                                </div>
                                <div class="courses_meta">
                                    <ul class="meta">
                                        <li><i class="fa fa-files-o"></i> <?php echo $no_of_lectures; ?> Lectures</li>
                                        <li><i class="fa fa-clock-o"></i> <?php echo $course_duration; ?></li>
                                    </ul>
                                </div>
                            </div>

                            <div class="accordion" id="accordionExample">
                                <div class="card">
                                    <div class="card-header" id="headingOne">
                                        <a href="#" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">Week 1</a>
                                    </div>

                                    <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
                                        <div class="card-body">
                                            <div class="curriculum_content">
                                                <h5 class="title">Beginners level</h5>
                                                <p>What do you think is better to receive after each lesson: a lovely looking badge or important skills you can immediately put into practice? We thought you might choose the latte</p>
                                                
                                                <div class="curriculum_list">
                                                    <span><i class="fa fa-file-o"></i> 1 video, 1 audio, 1 reading</span>
                                                    <ul>
                                                        <li><a href="#"><i class="fa fa-file-video-o"></i> Video: Greetings and Introductions</a></li>
                                                        <li><a href="#"><i class="fa fa-book"></i> Reading: Word Types</a></li>
                                                        <li><a href="#"><i class="fa fa-file-audio-o"></i> Audio: Listening Exercise</a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="card">
                                    <div class="card-header" id="headingTwo">
                                        <a href="#" class="collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">Week 2</a>
                                    </div>
                                    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
                                        <div class="card-body">
                                            <div class="curriculum_content">
                                                <h5 class="title">Beginners level</h5>
                                                <p>What do you think is better to receive after each lesson: a lovely looking badge or important skills you can immediately put into practice? We thought you might choose the latte</p>
                                                
                                                <div class="curriculum_list">
                                                    <span><i class="fa fa-file-o"></i> 1 video, 1 audio, 1 reading</span>
                                                    <ul>
                                                        <li><a href="#"><i class="fa fa-file-video-o"></i> Video: Greetings and Introductions</a></li>
                                                        <li><a href="#"><i class="fa fa-book"></i> Reading: Word Types</a></li>
                                                        <li><a href="#"><i class="fa fa-file-audio-o"></i> Audio: Listening Exercise</a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="card">
                                    <div class="card-header" id="headingThree">
                                        <a href="#" class="collapsed" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">Week 3</a>
                                    </div>
                                    <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
                                        <div class="card-body">
                                            <div class="curriculum_content">
                                                <h5 class="title">Beginners level</h5>
                                                <p>What do you think is better to receive after each lesson: a lovely looking badge or important skills you can immediately put into practice? We thought you might choose the latte</p>
                                                
                                                <div class="curriculum_list">
                                                    <span><i class="fa fa-file-o"></i> 1 video, 1 audio, 1 reading</span>
                                                    <ul>
                                                        <li><a href="#"><i class="fa fa-file-video-o"></i> Video: Greetings and Introductions</a></li>
                                                        <li><a href="#"><i class="fa fa-book"></i> Reading: Word Types</a></li>
                                                        <li><a href="#"><i class="fa fa-file-audio-o"></i> Audio: Listening Exercise</a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                      
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!--====== Courses Details PART ENDS ======-->

    <!--====== Footer PART START ======-->

    <?php include_once 'footer.php'; ?>

    <!--====== Footer PART ENDS ======-->

    <!--====== BACK TOP TOP PART START ======-->

    <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>

    <!--====== BACK TOP TOP PART ENDS ======-->

    









    <!--====== jquery js ======-->
    <script src="assets/js/vendor/modernizr-3.6.0.min.js"></script>
    <script src="assets/js/vendor/jquery-1.12.4.min.js"></script>

    <!--====== Bootstrap js ======-->
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/popper.min.js"></script>

    <!--====== Slick js ======-->
    <script src="assets/js/slick.min.js"></script>

    <!--====== Magnific Popup js ======-->
    <script src="assets/js/jquery.magnific-popup.min.js"></script>

    <!--====== Counter Up js ======-->
    <script src="assets/js/waypoints.min.js"></script>
    <script src="assets/js/jquery.counterup.min.js"></script>

    <!--====== Nice Select js ======-->
    <script src="assets/js/jquery.nice-select.min.js"></script>
    
    <!--====== Count Down js ======-->
    <script src="assets/js/jquery.countdown.min.js"></script>
    
    <!--====== Appear js ======-->
    <script src="assets/js/jquery.appear.min.js"></script>

    <!--====== Main js ======-->
    <script src="assets/js/main.js"></script>

</body>


<!-- Mirrored from raistheme.com/html/edustdy/edustdy/courses-details.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 19 Jun 2020 17:18:57 GMT -->
</html>
